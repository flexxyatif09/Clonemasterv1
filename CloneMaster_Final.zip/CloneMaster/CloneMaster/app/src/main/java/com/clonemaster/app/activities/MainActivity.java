package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.CloneAdapter;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CloneAdapter.CloneClickListener {

    private static final String TAG = "CloneMaster";
    private CloneAdapter cloneAdapter;
    private CloneManager cloneManager;
    private TextView tvAllocated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            setContentView(R.layout.activity_main);
            cloneManager = CloneManager.getInstance(this);
            setupViews();
            setupBottomNav();
        } catch (Exception e) {
            Log.e(TAG, "MainActivity onCreate crash: " + e.getMessage(), e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            refreshClones();
        } catch (Exception e) {
            Log.e(TAG, "onResume crash: " + e.getMessage(), e);
        }
    }

    private void setupViews() {
        tvAllocated = findViewById(R.id.tv_allocated);

        TextView tvSecureSpaceLabel = findViewById(R.id.tv_secure_space_label);
        if (tvSecureSpaceLabel != null) {
            tvSecureSpaceLabel.setText("SECURE SPACE ACTIVE — VIRTUAL DUAL ACCOUNT");
        }

        // Deploy New Clone button
        MaterialCardView deployCard = findViewById(R.id.card_deploy);
        if (deployCard != null) {
            deployCard.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(MainActivity.this, AddCloneActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Deploy button crash: " + e.getMessage(), e);
                    Toast.makeText(this, "Error opening clone list: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        View ivAvatar = findViewById(R.id.iv_avatar);
        if (ivAvatar != null) {
            ivAvatar.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(this, SettingsActivity.class));
                } catch (Exception e) {
                    Log.e(TAG, "Avatar click crash: " + e.getMessage(), e);
                }
            });
        }

        RecyclerView recyclerView = findViewById(R.id.rv_clones);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
            cloneAdapter = new CloneAdapter(this, this);
            recyclerView.setAdapter(cloneAdapter);
        }
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            try {
                if (id == R.id.nav_home) return true;
                else if (id == R.id.nav_add) { startActivity(new Intent(this, AddCloneActivity.class)); return true; }
                else if (id == R.id.nav_locker) { startActivity(new Intent(this, LockerActivity.class)); return true; }
                else if (id == R.id.nav_settings) { startActivity(new Intent(this, SettingsActivity.class)); return true; }
            } catch (Exception e) {
                Log.e(TAG, "BottomNav crash: " + e.getMessage(), e);
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            return false;
        });
    }

    private void refreshClones() {
        if (cloneAdapter == null || cloneManager == null) return;
        List<CloneInstance> clones = cloneManager.getCloneInstances();
        cloneAdapter.updateClones(clones);
        if (tvAllocated != null) tvAllocated.setText(clones.size() + " Allocated");
    }

    @Override
    public void onCloneClick(CloneInstance clone) {
        try {
            boolean launched = cloneManager.launchClone(clone);
            if (!launched) {
                new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("App Not Found")
                    .setMessage(clone.getAppName() + " is not installed.")
                    .setPositiveButton("OK", null)
                    .show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Launch error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCloneLongClick(CloneInstance clone) {
        String[] options = {"Launch App", clone.isHibernated() ? "Wake Up" : "Hibernate", "Remove Clone"};
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(clone.getAppName())
            .setItems(options, (dialog, which) -> {
                try {
                    if (which == 0) cloneManager.launchClone(clone);
                    else if (which == 1) {
                        if (clone.isHibernated()) cloneManager.wakeClone(clone);
                        else cloneManager.hibernateClone(clone);
                        refreshClones();
                    } else {
                        new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Remove Clone")
                            .setMessage("Remove " + clone.getAppName() + " clone?")
                            .setPositiveButton("Remove", (d, w) -> { cloneManager.removeClone(clone.getId()); refreshClones(); })
                            .setNegativeButton("Cancel", null).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }).show();
    }
}
