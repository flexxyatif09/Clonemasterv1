package com.clonemaster.app.workprofile;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.UserHandle;
import android.os.UserManager;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class WorkProfileManager {
    private static final String TAG = "WorkProfileManager";
    private static WorkProfileManager instance;
    private final Context context;
    private final DevicePolicyManager dpm;
    private final ComponentName adminComponent;

    private WorkProfileManager(Context context) {
        this.context = context.getApplicationContext();
        this.dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        this.adminComponent = new ComponentName(context, CloneMasterDeviceAdmin.class);
    }

    public static WorkProfileManager getInstance(Context context) {
        if (instance == null) instance = new WorkProfileManager(context);
        return instance;
    }

    /**
     * Work Profile exist karta hai phone pe?
     */
    public boolean isWorkProfileCreated() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return false;
        try {
            UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
            if (um == null) return false;

            // Android 30+ pe direct check
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return um.isManagedProfile();
            }

            // Older versions pe reflection se
            Method method = um.getClass().getMethod("isManagedProfile");
            return (boolean) method.invoke(um);
        } catch (Exception e) {
            Log.e(TAG, "isWorkProfileCreated: " + e.getMessage());
            return false;
        }
    }

    /**
     * Ye app Profile Owner hai?
     */
    public boolean isProfileOwner() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return false;
        try {
            return dpm != null && dpm.isProfileOwnerApp(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Work Profile setup ke liye intent return karo
     * User ko ye screen dikhao — Android khud Work Profile banata hai
     */
    public Intent getWorkProfileSetupIntent() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return null;
        try {
            Intent intent = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
            intent.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                    adminComponent);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                intent.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true);
            }
            return intent;
        } catch (Exception e) {
            Log.e(TAG, "getWorkProfileSetupIntent: " + e.getMessage());
            return null;
        }
    }

    /**
     * Work Profile mein app install karo
     */
    public void installAppInWorkProfile(String packageName, AppInstallCallback callback) {
        if (!isProfileOwner()) {
            if (callback != null) callback.onNeedManualInstall(packageName);
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                dpm.enableSystemApp(adminComponent, packageName);
                if (callback != null) callback.onSuccess();
            }
        } catch (Exception e) {
            Log.e(TAG, "installAppInWorkProfile: " + e.getMessage());
            if (callback != null) callback.onNeedManualInstall(packageName);
        }
    }

    /**
     * Work Profile mein app launch karo
     */
    public boolean launchAppInWorkProfile(String packageName) {
        try {
            PackageManager pm = context.getPackageManager();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Work profile ke saare users dhundho
                UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
                if (um == null) return false;

                List<UserHandle> profiles = um.getUserProfiles();
                for (UserHandle profile : profiles) {
                    // Apna user nahi — work profile user
                    if (!profile.equals(android.os.Process.myUserHandle())) {
                        Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            // Work profile mein launch
                            context.startActivity(launchIntent);
                            return true;
                        }
                    }
                }
            }

            // Fallback — direct launch
            Intent intent = pm.getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return true;
            }
            return false;

        } catch (Exception e) {
            Log.e(TAG, "launchAppInWorkProfile: " + e.getMessage());
            return false;
        }
    }

    /**
     * Work profile mein installed apps ki list
     */
    public List<String> getWorkProfileApps() {
        List<String> apps = new ArrayList<>();
        try {
            if (!isProfileOwner()) return apps;
            PackageManager pm = context.getPackageManager();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                // Work profile apps
                apps.add(context.getPackageName());
            }
        } catch (Exception e) {
            Log.e(TAG, "getWorkProfileApps: " + e.getMessage());
        }
        return apps;
    }

    public interface AppInstallCallback {
        void onSuccess();
        void onNeedManualInstall(String packageName);
        void onFailure(String error);
    }
}
