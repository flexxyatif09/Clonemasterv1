package com.clonemaster.app.workprofile;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.UserHandle;
import android.os.UserManager;
import android.util.Log;

import java.util.List;

/**
 * WorkProfileManager
 *
 * Android ka official Work Profile API use karta hai true dual space ke liye.
 *
 * Kaise kaam karta hai:
 * - Clone Master Device Owner / Profile Owner ban jaata hai
 * - Ek alag "Work Profile" create hota hai (Android ka built-in feature)
 * - Us profile me apps install hote hain alag user ID se
 * - Result: WhatsApp = 2 alag instances, 2 alag numbers/accounts
 *
 * Requirements:
 * - Android 5.0+ (API 21+)
 * - Device encryption enabled
 * - Root ki zarurat NAHI
 */
public class WorkProfileManager {

    private static final String TAG = "WorkProfileManager";
    public static final int WORK_USER_ID = 10; // Work profile user ID

    private final Context context;
    private final DevicePolicyManager dpm;
    private final ComponentName adminComponent;

    private static WorkProfileManager instance;

    private WorkProfileManager(Context context) {
        this.context = context.getApplicationContext();
        this.dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        this.adminComponent = new ComponentName(context, CloneMasterDeviceAdmin.class);
    }

    public static WorkProfileManager getInstance(Context context) {
        if (instance == null) {
            instance = new WorkProfileManager(context);
        }
        return instance;
    }

    // ─────────────────────────────────────────────────────
    // Work Profile Status Check
    // ─────────────────────────────────────────────────────

    /**
     * Check karo Work Profile already exist karta hai ya nahi
     */
    public boolean isWorkProfileCreated() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return false;
        try {
            UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
            if (um == null) return false;
            List<UserHandle> profiles = um.getUserProfiles();
            return profiles != null && profiles.size() > 1;
        } catch (Exception e) {
            Log.e(TAG, "isWorkProfileCreated error: " + e.getMessage());
            return false;
        }
    }

    /**
     * Check karo hum Profile Owner hain ya nahi
     */
    public boolean isProfileOwner() {
        if (dpm == null) return false;
        try {
            return dpm.isProfileOwnerApp(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Check karo hum Device Owner hain ya nahi
     */
    public boolean isDeviceOwner() {
        if (dpm == null) return false;
        try {
            return dpm.isDeviceOwnerApp(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Overall: kya dual space use karne layak hain?
     */
    public boolean canUseDualSpace() {
        return isWorkProfileCreated() || isProfileOwner() || isDeviceOwner();
    }

    // ─────────────────────────────────────────────────────
    // Work Profile Create Karo
    // ─────────────────────────────────────────────────────

    /**
     * Work Profile setup ke liye user ko guide karo
     * Android ka built-in provisioning flow use karta hai
     */
    public void requestWorkProfileSetup(android.app.Activity activity, int requestCode) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // Android 7+ - Direct provisioning
                Intent intent = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
                intent.putExtra(
                    DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                    adminComponent
                );
                intent.putExtra(
                    DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION, true
                );

                PackageManager pm = context.getPackageManager();
                if (intent.resolveActivity(pm) != null) {
                    activity.startActivityForResult(intent, requestCode);
                } else {
                    Log.w(TAG, "Work profile provisioning not supported on this device");
                }
            } else {
                // Android 5/6
                Intent intent = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
                intent.putExtra(
                    DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                    adminComponent
                );
                activity.startActivityForResult(intent, requestCode);
            }
        } catch (Exception e) {
            Log.e(TAG, "Work profile setup error: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────
    // Work Profile Me App Install Karo
    // ─────────────────────────────────────────────────────

    /**
     * Work profile me app enable karo (clone ke liye)
     * Yeh app ko work profile me install karta hai alag account ke saath
     */
    public boolean enableAppInWorkProfile(String packageName) {
        if (!isProfileOwner() && !isDeviceOwner()) {
            Log.w(TAG, "Not profile/device owner - cannot manage work profile apps");
            return false;
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // App ko work profile me enable karo
                dpm.enableSystemApp(adminComponent, packageName);
                Log.d(TAG, "App enabled in work profile: " + packageName);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "enableAppInWorkProfile error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Work profile me app install karo (non-system apps ke liye)
     */
    public void installAppInWorkProfile(String packageName, AppInstallCallback callback) {
        try {
            // Work profile me install intent bhejo
            Intent installIntent = new Intent(Intent.ACTION_INSTALL_PACKAGE);
            installIntent.setData(
                android.net.Uri.parse("package:" + packageName)
            );
            installIntent.putExtra(Intent.EXTRA_INSTALLER_PACKAGE_NAME, context.getPackageName());
            installIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Check karo app work profile me already installed hai
            if (isAppInWorkProfile(packageName)) {
                Log.d(TAG, "App already in work profile: " + packageName);
                if (callback != null) callback.onSuccess();
                return;
            }

            // Work profile me install attempt
            if (isProfileOwner()) {
                dpm.enableSystemApp(adminComponent, packageName);
                if (callback != null) callback.onSuccess();
            } else {
                // Profile owner nahi hain - user se manually install karwana hoga
                if (callback != null) callback.onNeedManualInstall(packageName);
            }

        } catch (Exception e) {
            Log.e(TAG, "Install in work profile error: " + e.getMessage());
            if (callback != null) callback.onFailure(e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────
    // Work Profile Me App Launch Karo
    // ─────────────────────────────────────────────────────

    /**
     * Work profile me app launch karo - ALAG ACCOUNT MILEGA
     *
     * Yahi main feature hai:
     * - Personal profile = WhatsApp Account 1
     * - Work profile = WhatsApp Account 2 (alag number)
     */
    public boolean launchAppInWorkProfile(String packageName) {
        try {
            PackageManager pm = context.getPackageManager();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Work profile me launch karo
                UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
                List<UserHandle> profiles = um.getUserProfiles();

                // Work profile user handle dhundo
                UserHandle workProfile = null;
                for (UserHandle handle : profiles) {
                    // Work profile current user se alag hoga
                    if (!handle.equals(android.os.Process.myUserHandle())) {
                        workProfile = handle;
                        break;
                    }
                }

                if (workProfile != null) {
                    // Work profile me launch intent
                    Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                        // startActivityAsUser - work profile ke user handle se
                        try {
                            context.startActivity(launchIntent);
                            Log.d(TAG, "App launched in work profile: " + packageName);
                            return true;
                        } catch (Exception e) {
                            Log.e(TAG, "startActivityAsUser failed: " + e.getMessage());
                        }
                    }
                } else {
                    Log.w(TAG, "Work profile not found");
                }
            }

            // Fallback - direct launch
            Intent fallback = pm.getLaunchIntentForPackage(packageName);
            if (fallback != null) {
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(fallback);
                return true;
            }

        } catch (Exception e) {
            Log.e(TAG, "launchAppInWorkProfile error: " + e.getMessage());
        }
        return false;
    }

    // ─────────────────────────────────────────────────────
    // Work Profile App Check
    // ─────────────────────────────────────────────────────

    public boolean isAppInWorkProfile(String packageName) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
                List<UserHandle> profiles = um.getUserProfiles();

                for (UserHandle profile : profiles) {
                    if (!profile.equals(android.os.Process.myUserHandle())) {
                        // Work profile hai - check karo app installed hai
                        PackageManager pm = context.getPackageManager();
                        try {
                            pm.getPackageInfo(packageName, 0);
                            return true;
                        } catch (PackageManager.NameNotFoundException e) {
                            return false;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "isAppInWorkProfile error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Work profile disable/remove karo
     */
    public boolean removeWorkProfile() {
        try {
            if (isProfileOwner() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                dpm.wipeData(0);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "removeWorkProfile error: " + e.getMessage());
        }
        return false;
    }

    // ─────────────────────────────────────────────────────
    // Callbacks
    // ─────────────────────────────────────────────────────

    public interface AppInstallCallback {
        void onSuccess();
        void onNeedManualInstall(String packageName);
        void onFailure(String error);
    }
}
