package com.clonemaster.app.virtual;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import java.io.File;

/**
 * VirtualAppEngine — ye class actual virtual environment manage karta hai.
 * Har clone ka apna alag data directory hota hai jisme app ka data store hota hai.
 * Ye Parallel Space / Dual Space jaise apps ka same approach hai.
 */
public class VirtualAppEngine {

    private static final String TAG = "VirtualAppEngine";
    private static VirtualAppEngine instance;
    private final Context context;

    // Har clone ka data yahan store hoga: /data/data/com.clonemaster.app/virtual/{cloneId}/{pkg}/
    private final File virtualRoot;

    private VirtualAppEngine(Context ctx) {
        this.context = ctx.getApplicationContext();
        this.virtualRoot = new File(context.getFilesDir(), "virtual_spaces");
        if (!virtualRoot.exists()) virtualRoot.mkdirs();
    }

    public static synchronized VirtualAppEngine getInstance(Context ctx) {
        if (instance == null) instance = new VirtualAppEngine(ctx);
        return instance;
    }

    /**
     * Naya virtual space banao ek app ke liye.
     * Clone ID unique identifier hai — isi se alag alag accounts bante hain.
     */
    public boolean createVirtualSpace(String cloneId, String packageName) {
        try {
            File spaceDir = getSpaceDir(cloneId, packageName);
            if (!spaceDir.exists()) {
                boolean created = spaceDir.mkdirs();
                if (!created) {
                    Log.e(TAG, "Space dir create nahi hua: " + spaceDir.getAbsolutePath());
                    return false;
                }
            }

            // Sub-directories banao — jaise original app ka structure hota hai
            new File(spaceDir, "shared_prefs").mkdirs();
            new File(spaceDir, "databases").mkdirs();
            new File(spaceDir, "files").mkdirs();
            new File(spaceDir, "cache").mkdirs();

            // Space metadata save karo
            VirtualSpaceInfo info = new VirtualSpaceInfo(cloneId, packageName,
                    System.currentTimeMillis());
            saveSpaceInfo(info);

            Log.d(TAG, "Virtual space created: " + cloneId + " for " + packageName);
            return true;

        } catch (Exception e) {
            Log.e(TAG, "createVirtualSpace error: " + e.getMessage());
            return false;
        }
    }

    /**
     * App launch karo virtual space mein.
     * VirtualActivity ek container hai jo app ko isolated environment mein run karta hai.
     */
    public boolean launchInVirtualSpace(String cloneId, String packageName, String appName) {
        try {
            // Check karo app installed hai
            PackageManager pm = context.getPackageManager();
            ApplicationInfo appInfo;
            try {
                appInfo = pm.getApplicationInfo(packageName, 0);
            } catch (PackageManager.NameNotFoundException e) {
                Log.e(TAG, "App not installed: " + packageName);
                return false;
            }

            // Space exist karta hai?
            File spaceDir = getSpaceDir(cloneId, packageName);
            if (!spaceDir.exists()) {
                createVirtualSpace(cloneId, packageName);
            }

            // VirtualContainerActivity mein launch karo
            Intent launchIntent = new Intent(context, VirtualContainerActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            launchIntent.putExtra(VirtualContainerActivity.EXTRA_CLONE_ID, cloneId);
            launchIntent.putExtra(VirtualContainerActivity.EXTRA_PACKAGE_NAME, packageName);
            launchIntent.putExtra(VirtualContainerActivity.EXTRA_APP_NAME, appName);
            launchIntent.putExtra(VirtualContainerActivity.EXTRA_SPACE_DIR,
                    spaceDir.getAbsolutePath());
            launchIntent.putExtra(VirtualContainerActivity.EXTRA_APP_SOURCE,
                    appInfo.sourceDir);
            context.startActivity(launchIntent);
            return true;

        } catch (Exception e) {
            Log.e(TAG, "launchInVirtualSpace error: " + e.getMessage());
            return false;
        }
    }

    /**
     * Virtual space delete karo — data bhi hata do
     */
    public boolean destroyVirtualSpace(String cloneId, String packageName) {
        try {
            File spaceDir = getSpaceDir(cloneId, packageName);
            deleteRecursive(spaceDir);
            Log.d(TAG, "Virtual space destroyed: " + cloneId);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "destroyVirtualSpace error: " + e.getMessage());
            return false;
        }
    }

    public File getSpaceDir(String cloneId, String packageName) {
        return new File(virtualRoot, cloneId + File.separator + packageName);
    }

    public File getVirtualRoot() {
        return virtualRoot;
    }

    private void saveSpaceInfo(VirtualSpaceInfo info) {
        // Simple file mein save karo
        File infoFile = new File(getSpaceDir(info.cloneId, info.packageName), ".space_info");
        try {
            String content = info.cloneId + "\n" + info.packageName + "\n" + info.createdAt;
            java.io.FileWriter fw = new java.io.FileWriter(infoFile);
            fw.write(content);
            fw.close();
        } catch (Exception e) {
            Log.e(TAG, "saveSpaceInfo error: " + e.getMessage());
        }
    }

    private void deleteRecursive(File file) {
        if (file.isDirectory()) {
            for (File child : file.listFiles() != null ? file.listFiles() : new File[0]) {
                deleteRecursive(child);
            }
        }
        file.delete();
    }

    public static class VirtualSpaceInfo {
        public final String cloneId;
        public final String packageName;
        public final long createdAt;

        public VirtualSpaceInfo(String cloneId, String packageName, long createdAt) {
            this.cloneId = cloneId;
            this.packageName = packageName;
            this.createdAt = createdAt;
        }
    }
}
