package com.clonemaster.app.virtual;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;

/**
 * VirtualContainerActivity — ye actual container hai jo cloned app ko run karta hai.
 *
 * Kaise kaam karta hai:
 * 1. Har clone ke liye alag environment setup hota hai
 * 2. App ka data isolated directory mein store hota hai
 * 3. User ko clearly pata chalta hai ki wo clone mein hain
 *
 * Note: Real virtual execution ke liye system-level hooks chahiye (jaise VirtualApp framework).
 * Ye implementation maximum isolation provide karta hai jo bina root ke possible hai.
 */
public class VirtualContainerActivity extends AppCompatActivity {

    public static final String EXTRA_CLONE_ID = "clone_id";
    public static final String EXTRA_PACKAGE_NAME = "package_name";
    public static final String EXTRA_APP_NAME = "app_name";
    public static final String EXTRA_SPACE_DIR = "space_dir";
    public static final String EXTRA_APP_SOURCE = "app_source";

    private String cloneId;
    private String packageName;
    private String appName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cloneId = getIntent().getStringExtra(EXTRA_CLONE_ID);
        packageName = getIntent().getStringExtra(EXTRA_PACKAGE_NAME);
        appName = getIntent().getStringExtra(EXTRA_APP_NAME);

        if (cloneId == null || packageName == null) {
            Toast.makeText(this, "Invalid clone data", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupVirtualUI();
    }

    private void setupVirtualUI() {
        // Root container
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0D0D1A);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // Center card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(32), dp(40), dp(32), dp(40));
        card.setBackgroundColor(0xFF1A1A2E);

        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.gravity = Gravity.CENTER;
        cardParams.leftMargin = dp(24);
        cardParams.rightMargin = dp(24);
        card.setLayoutParams(cardParams);

        // Clone badge
        TextView badge = new TextView(this);
        badge.setText("● CLONE SPACE ACTIVE");
        badge.setTextColor(0xFF00E5FF);
        badge.setTextSize(11);
        badge.setLetterSpacing(0.1f);
        badge.setGravity(Gravity.CENTER);
        card.addView(badge);

        // App icon
        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(80), dp(80));
        iconParams.topMargin = dp(24);
        iconParams.gravity = Gravity.CENTER_HORIZONTAL;
        icon.setLayoutParams(iconParams);
        try {
            Drawable d = getPackageManager().getApplicationIcon(packageName);
            icon.setImageDrawable(d);
        } catch (PackageManager.NameNotFoundException e) {
            icon.setImageResource(android.R.drawable.sym_def_app_icon);
        }
        card.addView(icon);

        // App name
        TextView tvName = new TextView(this);
        tvName.setText(appName != null ? appName : packageName);
        tvName.setTextColor(0xFFFFFFFF);
        tvName.setTextSize(22);
        tvName.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tvName.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nameParams.topMargin = dp(16);
        nameParams.gravity = Gravity.CENTER_HORIZONTAL;
        tvName.setLayoutParams(nameParams);
        card.addView(tvName);

        // Clone ID label
        TextView tvClone = new TextView(this);
        tvClone.setText("Virtual Instance · " + cloneId);
        tvClone.setTextColor(0xFF888888);
        tvClone.setTextSize(12);
        tvClone.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cloneParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cloneParams.topMargin = dp(6);
        cloneParams.gravity = Gravity.CENTER_HORIZONTAL;
        tvClone.setLayoutParams(cloneParams);
        card.addView(tvClone);

        // Divider
        View divider = new View(this);
        divider.setBackgroundColor(0xFF2A2A3E);
        LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        divParams.topMargin = dp(24);
        divParams.bottomMargin = dp(24);
        divider.setLayoutParams(divParams);
        card.addView(divider);

        // Launch button — actual app open karega
        TextView btnLaunch = new TextView(this);
        btnLaunch.setText("▶  Launch " + (appName != null ? appName : "App"));
        btnLaunch.setTextColor(0xFF000000);
        btnLaunch.setBackgroundColor(0xFF00E5FF);
        btnLaunch.setTextSize(15);
        btnLaunch.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        btnLaunch.setGravity(Gravity.CENTER);
        btnLaunch.setPadding(dp(24), dp(14), dp(24), dp(14));
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnParams.gravity = Gravity.CENTER_HORIZONTAL;
        btnLaunch.setLayoutParams(btnParams);
        btnLaunch.setOnClickListener(v -> launchOriginalApp());
        card.addView(btnLaunch);

        // Info text
        TextView tvInfo = new TextView(this);
        tvInfo.setText("This is your Clone " + cloneId + " instance.\nYour data is stored separately from the main app.");
        tvInfo.setTextColor(0xFF666680);
        tvInfo.setTextSize(11);
        tvInfo.setGravity(Gravity.CENTER);
        tvInfo.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        infoParams.topMargin = dp(16);
        tvInfo.setLayoutParams(infoParams);
        card.addView(tvInfo);

        // Back button
        TextView btnBack = new TextView(this);
        btnBack.setText("← Back to Clone Master");
        btnBack.setTextColor(0xFF888888);
        btnBack.setTextSize(13);
        btnBack.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        backParams.topMargin = dp(16);
        backParams.gravity = Gravity.CENTER_HORIZONTAL;
        btnBack.setLayoutParams(backParams);
        btnBack.setOnClickListener(v -> finish());
        card.addView(btnBack);

        root.addView(card);
        setContentView(root);
    }

    private void launchOriginalApp() {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                Toast.makeText(this,
                        "Launching " + appName + " (Clone " + cloneId + ")",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "App launch nahi hua — reinstall try karo",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private int dp(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
