package com.clonemaster.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppViewHolder> {

    public interface AppClickListener {
        void onAppAdd(AppInfo appInfo);
    }

    private final Context context;
    private final AppClickListener listener;
    private List<AppInfo> apps = new ArrayList<>();
    private CloneManager cloneManager;

    public AppListAdapter(Context context, AppClickListener listener) {
        this.context = context;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void updateApps(List<AppInfo> newApps, CloneManager manager) {
        this.cloneManager = manager;

        // DiffUtil — sirf changed items update hoti hain, pura list refresh nahi
        DiffUtil.DiffResult diff = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return apps.size(); }
            @Override public int getNewListSize() { return newApps.size(); }

            @Override
            public boolean areItemsTheSame(int oldPos, int newPos) {
                return apps.get(oldPos).getPackageName()
                    .equals(newApps.get(newPos).getPackageName());
            }

            @Override
            public boolean areContentsTheSame(int oldPos, int newPos) {
                AppInfo o = apps.get(oldPos);
                AppInfo n = newApps.get(newPos);
                return o.getAppName().equals(n.getAppName())
                    && o.getPackageName().equals(n.getPackageName());
            }
        });

        apps = new ArrayList<>(newApps);
        diff.dispatchUpdatesTo(this);
    }

    @Override
    public long getItemId(int position) {
        return apps.get(position).getPackageName().hashCode();
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        holder.bind(apps.get(position));
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    class AppViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivIcon;
        private final TextView tvName, tvCategory;
        private final MaterialButton btnAdd;

        AppViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_app_icon);
            tvName = itemView.findViewById(R.id.tv_app_name);
            tvCategory = itemView.findViewById(R.id.tv_category);
            btnAdd = itemView.findViewById(R.id.btn_add);
        }

        void bind(AppInfo app) {
            // Icon
            if (ivIcon != null) {
                if (app.getIcon() != null) {
                    ivIcon.setImageDrawable(app.getIcon());
                } else {
                    ivIcon.setImageResource(android.R.drawable.sym_def_app_icon);
                }
            }

            if (tvName != null) tvName.setText(app.getAppName());

            if (tvCategory != null) {
                tvCategory.setText(app.getCategory() + " • " + app.getFormattedSize());
            }

            boolean isCloned = cloneManager != null
                && cloneManager.isAlreadyCloned(app.getPackageName());

            if (btnAdd != null) {
                if (isCloned) {
                    btnAdd.setText("Added ✓");
                    btnAdd.setEnabled(false);
                    btnAdd.setAlpha(0.45f);
                    btnAdd.setOnClickListener(null);
                } else {
                    btnAdd.setText("+ Add");
                    btnAdd.setEnabled(true);
                    btnAdd.setAlpha(1f);
                    btnAdd.setOnClickListener(v -> {
                        if (listener != null) listener.onAppAdd(app);
                    });
                }
            }

            itemView.setOnClickListener(v -> {
                if (!isCloned && listener != null) listener.onAppAdd(app);
            });
        }
    }
}
