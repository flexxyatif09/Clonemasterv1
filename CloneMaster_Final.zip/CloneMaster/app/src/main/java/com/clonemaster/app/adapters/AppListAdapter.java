package com.clonemaster.app.adapters;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.clonemaster.app.R;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppViewHolder> {

    public interface AppClickListener {
        void onAppAdd(AppInfo appInfo);
    }

    private final Context context;
    private final AppClickListener listener;
    private List<AppInfo> apps = new ArrayList<>();
    private CloneManager cloneManager;

    public AppListAdapter(Context context, AppClickListener listener) {
        this.context = context;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void updateApps(List<AppInfo> newApps, CloneManager manager) {
        this.cloneManager = manager;
        this.apps = new ArrayList<>(newApps);
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return apps.get(position).getPackageName().hashCode();
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        holder.bind(apps.get(position));
    }

    @Override
    public int getItemCount() { return apps.size(); }

    class AppViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivIcon;
        final TextView tvName, tvCategory;
        final MaterialButton btnAdd;

        AppViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_app_icon);
            tvName = itemView.findViewById(R.id.tv_app_name);
            tvCategory = itemView.findViewById(R.id.tv_category);
            btnAdd = itemView.findViewById(R.id.btn_add);
        }

        void bind(AppInfo app) {
            // App icon — Glide se load karo (fast, cached, non-blocking)
            if (ivIcon != null) {
                try {
                    Drawable icon = app.getIcon();
                    if (icon != null) {
                        ivIcon.setImageDrawable(icon);
                    } else {
                        // Glide PackageManager se icon load karega — smooth aur cached
                        PackageManager pm = context.getPackageManager();
                        try {
                            Drawable d = pm.getApplicationIcon(app.getPackageName());
                            ivIcon.setImageDrawable(d);
                        } catch (Exception e) {
                            ivIcon.setImageResource(android.R.drawable.sym_def_app_icon);
                        }
                    }
                } catch (Exception e) {
                    ivIcon.setImageResource(android.R.drawable.sym_def_app_icon);
                }
            }

            if (tvName != null) tvName.setText(app.getAppName());
            if (tvCategory != null) {
                String info = app.getCategory();
                if (!app.getFormattedSize().equals("Unknown"))
                    info += " • " + app.getFormattedSize();
                tvCategory.setText(info);
            }

            boolean isCloned = cloneManager != null
                && cloneManager.isAlreadyCloned(app.getPackageName());

            if (btnAdd != null) {
                if (isCloned) {
                    btnAdd.setText("Added ✓");
                    btnAdd.setEnabled(false);
                    btnAdd.setAlpha(0.4f);
                    btnAdd.setOnClickListener(null);
                } else {
                    btnAdd.setText("+ Add");
                    btnAdd.setEnabled(true);
                    btnAdd.setAlpha(1f);
                    btnAdd.setOnClickListener(v -> {
                        if (listener != null) listener.onAppAdd(app);
                    });
                }
            }

            itemView.setOnClickListener(v -> {
                if (!isCloned && listener != null) listener.onAppAdd(app);
            });
        }
    }
}
