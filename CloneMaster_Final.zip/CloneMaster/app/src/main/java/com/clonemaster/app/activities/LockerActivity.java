package com.clonemaster.app.activities;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LockerActivity extends AppCompatActivity {

    private CloneManager cloneManager;
    private AppListAdapter adapter;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locker);
        cloneManager = CloneManager.getInstance(this);
        setupBottomNav();
        setupViews();
    }

    private void setupViews() {
        TextView tvTitle = findViewById(R.id.tv_locker_title);
        if (tvTitle != null) tvTitle.setText("Privacy Locker");

        RecyclerView rv = findViewById(R.id.rv_locked_apps);
        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
            adapter = new AppListAdapter(this, appInfo ->
                Toast.makeText(this, appInfo.getAppName() + " added to locker",
                    Toast.LENGTH_SHORT).show()
            );
            rv.setAdapter(adapter);
        }

        // Background thread pe load karo — main thread block nahi hoga
        executor.execute(() -> {
            List<AppInfo> apps = loadInstalledApps();
            mainHandler.post(() -> {
                if (!isDestroyed() && adapter != null) {
                    adapter.updateApps(apps, cloneManager);
                }
            });
        });
    }

    private List<AppInfo> loadInstalledApps() {
        List<AppInfo> apps = new ArrayList<>();
        PackageManager pm = getPackageManager();
        try {
            List<ApplicationInfo> installed =
                pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo info : installed) {
                if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;
                if (info.packageName.equals(getPackageName())) continue;
                if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                try {
                    String name = pm.getApplicationLabel(info).toString();
                    Drawable icon = pm.getApplicationIcon(info.packageName);
                    long size = 0;
                    try { size = new java.io.File(info.sourceDir).length(); } catch (Exception ignored) {}
                    apps.add(new AppInfo(name, info.packageName, icon, size, ""));
                } catch (Exception ignored) {}
            }
            apps.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));
        } catch (Exception ignored) {}
        return apps;
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_locker);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class)); finish(); return true;
            } else if (id == R.id.nav_add) {
                startActivity(new Intent(this, AddCloneActivity.class)); return true;
            } else if (id == R.id.nav_locker) {
                return true;
            } else if (id == R.id.nav_settings) {
                startActivity(new Intent(this, SettingsActivity.class)); return true;
            }
            return false;
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
