package com.clonemaster.app.activities;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;
import com.clonemaster.app.workprofile.CloneMasterDeviceAdmin;
import com.clonemaster.app.workprofile.WorkProfileManager;
import com.google.android.material.button.MaterialButton;

/**
 * WorkProfileSetupActivity
 *
 * Pehli baar user ko Work Profile setup karne guide karta hai.
 * Yahi step se true 2nd account milega.
 *
 * Flow:
 * 1. User "Enable Work Profile" button dabaata hai
 * 2. Android ka built-in Work Profile setup screen khulta hai
 * 3. Setup complete hone ke baad:
 *    - WhatsApp clone = 2nd number se login
 *    - Instagram clone = 2nd account
 *    - Koi bhi app = alag account
 */
public class WorkProfileSetupActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_WORK_PROFILE = 1001;
    private static final int REQUEST_CODE_DEVICE_ADMIN = 1002;

    private WorkProfileManager workProfileManager;
    private MaterialButton btnSetup;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_profile_setup);

        workProfileManager = WorkProfileManager.getInstance(this);

        setupViews();
        checkCurrentStatus();
    }

    private void setupViews() {
        btnSetup = findViewById(R.id.btn_setup_work_profile);
        tvStatus = findViewById(R.id.tv_setup_status);

        TextView btnSkip = findViewById(R.id.btn_skip);
        if (btnSkip != null) {
            btnSkip.setOnClickListener(v -> goToMain());
        }

        if (btnSetup != null) {
            btnSetup.setOnClickListener(v -> startWorkProfileSetup());
        }

        // Admin enable button
        MaterialButton btnAdmin = findViewById(R.id.btn_enable_admin);
        if (btnAdmin != null) {
            btnAdmin.setOnClickListener(v -> requestDeviceAdmin());
        }
    }

    private void checkCurrentStatus() {
        if (workProfileManager.isWorkProfileCreated()) {
            // Already setup hai
            updateStatus("✅ Work Profile Active\n2nd account ready!", true);
            if (btnSetup != null) btnSetup.setText("Continue →");
            if (btnSetup != null) btnSetup.setOnClickListener(v -> goToMain());
        } else if (workProfileManager.isProfileOwner()) {
            updateStatus("✅ Profile Owner Active\nCreating work space...", false);
        } else {
            updateStatus("Setup work profile to enable 2nd accounts", false);
        }
    }

    private void startWorkProfileSetup() {
        // Method 1: Direct Work Profile provisioning
        workProfileManager.requestWorkProfileSetup(this, REQUEST_CODE_WORK_PROFILE);
    }

    private void requestDeviceAdmin() {
        ComponentName adminComponent = new ComponentName(this, CloneMasterDeviceAdmin.class);
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Clone Master needs admin access to create isolated work profiles for app cloning. " +
            "This enables true 2nd accounts for WhatsApp, Instagram, etc.");
        startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_WORK_PROFILE) {
            if (resultCode == Activity.RESULT_OK) {
                updateStatus("✅ Work Profile Created!\n2nd account ready for all apps!", true);
                if (btnSetup != null) {
                    btnSetup.setText("Continue →");
                    btnSetup.setOnClickListener(v -> goToMain());
                }
            } else {
                updateStatus("Work profile setup cancelled.\nYou can try again later.", false);
            }
        } else if (requestCode == REQUEST_CODE_DEVICE_ADMIN) {
            if (resultCode == Activity.RESULT_OK) {
                updateStatus("✅ Admin access granted!\nNow creating work profile...", false);
                // Admin mil gaya - ab work profile banao
                workProfileManager.requestWorkProfileSetup(this, REQUEST_CODE_WORK_PROFILE);
            } else {
                updateStatus("Admin access denied.\nWork profile needs admin permission.", false);
            }
        }
    }

    private void updateStatus(String message, boolean success) {
        if (tvStatus != null) {
            tvStatus.setText(message);
            tvStatus.setTextColor(getColor(
                success ? R.color.accent_cyan : R.color.text_secondary));
        }
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
