package com.clonemaster.app.activities;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.workprofile.WorkProfileManager;

public class WorkProfileSetupActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PROVISION = 1001;
    private WorkProfileManager wpManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wpManager = WorkProfileManager.getInstance(this);

        // Agar already setup hai — seedha main pe jao
        if (wpManager.isWorkProfileCreated() || wpManager.isProfileOwner()) {
            Toast.makeText(this, "✅ Work Profile already active!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        buildSetupUI();
    }

    private void buildSetupUI() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0D0D1A);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setBackgroundColor(0xFF1A1A2E);
        card.setPadding(dp(28), dp(36), dp(28), dp(36));

        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.gravity = Gravity.CENTER;
        cardParams.leftMargin = dp(20);
        cardParams.rightMargin = dp(20);
        card.setLayoutParams(cardParams);

        // Icon
        TextView icon = new TextView(this);
        icon.setText("🔐");
        icon.setTextSize(52);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        // Title
        TextView title = new TextView(this);
        title.setText("Work Profile Setup");
        title.setTextColor(0xFF00E5FF);
        title.setTextSize(22);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(16);
        tp.gravity = Gravity.CENTER_HORIZONTAL;
        title.setLayoutParams(tp);
        card.addView(title);

        // Description
        TextView desc = new TextView(this);
        desc.setText("Clone Master ek alag secure Work Profile banayega.\n\n" +
                "✅ Alag account — WhatsApp, Instagram sab 2nd account\n" +
                "✅ Data completely isolated\n" +
                "✅ Bina root ke kaam karta hai\n\n" +
                "Android aapko setup guide karega — sirf Next tap karte jao.");
        desc.setTextColor(0xFFAAAAAA);
        desc.setTextSize(14);
        desc.setLineSpacing(dp(4), 1.0f);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dp2.topMargin = dp(14);
        desc.setLayoutParams(dp2);
        card.addView(desc);

        // Setup button
        TextView btnSetup = new TextView(this);
        btnSetup.setText("▶  Setup Work Profile");
        btnSetup.setTextColor(0xFF000000);
        btnSetup.setBackgroundColor(0xFF00E5FF);
        btnSetup.setTextSize(16);
        btnSetup.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        btnSetup.setGravity(Gravity.CENTER);
        btnSetup.setPadding(dp(24), dp(16), dp(24), dp(16));
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnParams.topMargin = dp(28);
        btnSetup.setLayoutParams(btnParams);
        btnSetup.setOnClickListener(v -> startWorkProfileSetup());
        card.addView(btnSetup);

        // Skip button
        TextView btnSkip = new TextView(this);
        btnSkip.setText("Skip — use without Work Profile");
        btnSkip.setTextColor(0xFF555577);
        btnSkip.setTextSize(12);
        btnSkip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams skipParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        skipParams.topMargin = dp(16);
        skipParams.gravity = Gravity.CENTER_HORIZONTAL;
        btnSkip.setLayoutParams(skipParams);
        btnSkip.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
        card.addView(btnSkip);

        root.addView(card);
        setContentView(root);
    }

    private void startWorkProfileSetup() {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                Toast.makeText(this,
                        "Work Profile ke liye Android 5.0+ chahiye",
                        Toast.LENGTH_LONG).show();
                return;
            }

            Intent setupIntent = wpManager.getWorkProfileSetupIntent();
            if (setupIntent == null) {
                Toast.makeText(this,
                        "Work Profile is pehle se exist karta hai ya supported nahi hai",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return;
            }

            // Check karo intent resolve hoti hai
            if (setupIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(setupIntent, REQUEST_CODE_PROVISION);
            } else {
                Toast.makeText(this,
                        "Ye device Work Profile support nahi karta",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PROVISION) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(this,
                        "✅ Work Profile setup complete! Ab aap apps clone kar sakte ho.",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,
                        "Work Profile setup cancel hua — bina iske bhi app use kar sakte ho",
                        Toast.LENGTH_SHORT).show();
            }
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    private int dp(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
