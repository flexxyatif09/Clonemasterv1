package com.clonemaster.app.workprofile;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class CloneMasterDeviceAdmin extends DeviceAdminReceiver {
    private static final String TAG = "CloneMasterAdmin";

    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        // Work Profile setup complete — ab app enable karo
        Log.d(TAG, "Work Profile provisioning complete!");
        try {
            // Main app ko work profile mein enable karo
            Intent launch = new Intent(context,
                com.clonemaster.app.activities.MainActivity.class);
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(launch);
        } catch (Exception e) {
            Log.e(TAG, "onProfileProvisioningComplete error: " + e.getMessage());
        }
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        Log.d(TAG, "Device Admin enabled");
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        Log.d(TAG, "Device Admin disabled");
    }
}
