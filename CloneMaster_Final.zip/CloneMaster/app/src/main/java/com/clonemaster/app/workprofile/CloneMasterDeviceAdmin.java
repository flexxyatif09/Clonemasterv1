package com.clonemaster.app.workprofile;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * CloneMasterDeviceAdmin
 *
 * Device Admin Receiver - Work Profile ke liye zaruri hai.
 * Yeh Clone Master ko profile owner banata hai taaki:
 * - Work profile create kar sake
 * - Apps ko work profile me install kar sake
 * - 2nd account ke liye alag environment manage kar sake
 */
public class CloneMasterDeviceAdmin extends DeviceAdminReceiver {

    private static final String TAG = "CloneMasterAdmin";

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        Log.d(TAG, "Device Admin enabled - Clone Master can now manage work profiles");
        Toast.makeText(context, "Clone Master: Admin access granted ✓", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        Log.d(TAG, "Device Admin disabled");
        Toast.makeText(context, "Clone Master: Admin access removed", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        super.onProfileProvisioningComplete(context, intent);
        Log.d(TAG, "Work Profile provisioning complete!");

        // Work profile ready ho gaya - setup complete karo
        try {
            android.app.admin.DevicePolicyManager dpm =
                (android.app.admin.DevicePolicyManager) context.getSystemService(
                    Context.DEVICE_POLICY_SERVICE);

            android.content.ComponentName adminComponent =
                new android.content.ComponentName(context, CloneMasterDeviceAdmin.class);

            // Profile owner set karo
            // Work profile me Clone Master ko add karo
            Intent launchIntent = new Intent(context, com.clonemaster.app.activities.MainActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(launchIntent);

        } catch (Exception e) {
            Log.e(TAG, "Profile provisioning setup error: " + e.getMessage());
        }
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Disabling admin will remove work profile and 2nd account access.";
    }

    @Override
    public void onPasswordChanged(Context context, Intent intent) {
        super.onPasswordChanged(context, intent);
        Log.d(TAG, "Device password changed");
    }

    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        super.onPasswordFailed(context, intent);
        Log.d(TAG, "Device password failed attempt");
    }

    @Override
    public void onPasswordSucceeded(Context context, Intent intent) {
        super.onPasswordSucceeded(context, intent);
        Log.d(TAG, "Device password succeeded");
    }
}
