package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.CloneManager;
import com.clonemaster.app.utils.PrefsManager;
import com.clonemaster.app.workprofile.WorkProfileManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(R.layout.activity_splash);

        try {
            TextView tvTitle = findViewById(R.id.tv_title);
            TextView tvSubtitle = findViewById(R.id.tv_subtitle);
            if (tvTitle != null) {
                AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
                fadeIn.setDuration(600);
                fadeIn.setFillAfter(true);
                tvTitle.startAnimation(fadeIn);
            }
            if (tvSubtitle != null) {
                AlphaAnimation fadeIn2 = new AlphaAnimation(0f, 1f);
                fadeIn2.setDuration(800);
                fadeIn2.setStartOffset(200);
                fadeIn2.setFillAfter(true);
                tvSubtitle.startAnimation(fadeIn2);
            }
        } catch (Exception ignored) {}

        CloneManager.getInstance(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            try {
                PrefsManager prefs = PrefsManager.getInstance(this);
                WorkProfileManager wpManager = WorkProfileManager.getInstance(this);

                Intent intent;
                if (prefs.hasPin()) {
                    // PIN hai — pehle PIN verify karo
                    intent = new Intent(this, PinActivity.class);
                } else if (!prefs.isFirstLaunch() ) {
                    // Pehle launch nahi — seedha main
                    intent = new Intent(this, MainActivity.class);
                } else {
                    // Pehli baar — Work Profile setup dikhao
                    prefs.setFirstLaunch(false);
                    intent = new Intent(this, WorkProfileSetupActivity.class);
                }
                startActivity(intent);
                finish();
            } catch (Exception e) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        }, 900);
    }
}
