package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.CloneManager;
import com.clonemaster.app.utils.PrefsManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(R.layout.activity_splash);

        // Animation
        try {
            TextView tvTitle = findViewById(R.id.tv_title);
            TextView tvSubtitle = findViewById(R.id.tv_subtitle);

            if (tvTitle != null) {
                AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
                fadeIn.setDuration(600);
                fadeIn.setFillAfter(true);
                tvTitle.startAnimation(fadeIn);
            }
            if (tvSubtitle != null) {
                AlphaAnimation fadeIn2 = new AlphaAnimation(0f, 1f);
                fadeIn2.setDuration(800);
                fadeIn2.setStartOffset(200);
                fadeIn2.setFillAfter(true);
                tvSubtitle.startAnimation(fadeIn2);
            }
        } catch (Exception ignored) {}

        // CloneManager background load shuru karo abhi se
        CloneManager.getInstance(this);

        // Sirf 800ms wait — professional apps ki tarah fast launch
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            try {
                Intent intent;
                if (PrefsManager.getInstance(this).hasPin()) {
                    intent = new Intent(this, PinActivity.class);
                } else {
                    intent = new Intent(this, MainActivity.class);
                }
                startActivity(intent);
                finish();
            } catch (Exception e) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        }, 800);
    }
}
