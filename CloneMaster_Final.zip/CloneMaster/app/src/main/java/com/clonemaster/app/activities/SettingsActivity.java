package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.CloneManager;
import com.clonemaster.app.utils.PrefsManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

public class SettingsActivity extends AppCompatActivity {

    private PrefsManager prefsManager;
    private CloneManager cloneManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefsManager = PrefsManager.getInstance(this);
        cloneManager = CloneManager.getInstance(this);
        setupViews();
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateWorkProfileStatus();
    }

    private void setupViews() {
        // Storage Cleaner
        TextView tvStorage = findViewById(R.id.tv_storage_saved);
        LinearProgressIndicator progress = findViewById(R.id.progress_optimization);
        TextView tvOpt = findViewById(R.id.tv_optimization);
        if (tvStorage != null) tvStorage.setText(String.format("%.1f", cloneManager.getStorageSaved()));
        if (progress != null) progress.setProgress(cloneManager.getOptimizationPercent());
        if (tvOpt != null) tvOpt.setText(cloneManager.getOptimizationPercent() + "% Optimized");

        MaterialButton btnDeepClean = findViewById(R.id.btn_deep_clean);
        if (btnDeepClean != null) {
            btnDeepClean.setOnClickListener(v -> {
                btnDeepClean.setText("Cleaning...");
                btnDeepClean.setEnabled(false);
                v.postDelayed(() -> {
                    btnDeepClean.setText("✓ Deep Clean Complete");
                    btnDeepClean.setEnabled(true);
                    Toast.makeText(this, "Storage optimized!", Toast.LENGTH_SHORT).show();
                }, 2000);
            });
        }

        // Security switches
        SwitchCompat switchInvisible = findViewById(R.id.switch_invisible);
        if (switchInvisible != null) {
            switchInvisible.setChecked(prefsManager.isInvisibleInstall());
            switchInvisible.setOnCheckedChangeListener((b, checked) -> prefsManager.setInvisibleInstall(checked));
        }

        SwitchCompat switchNotif = findViewById(R.id.switch_notification);
        if (switchNotif != null) {
            switchNotif.setChecked(prefsManager.isNotificationSegregation());
            switchNotif.setOnCheckedChangeListener((b, checked) -> prefsManager.setNotificationSegregation(checked));
        }

        android.view.View lockRow = findViewById(R.id.row_security_lock);
        if (lockRow != null) lockRow.setOnClickListener(v -> startActivity(new Intent(this, SetPinActivity.class)));

        // Work Profile setup button
        MaterialButton btnWorkProfile = findViewById(R.id.btn_work_profile);
        if (btnWorkProfile != null) {
            btnWorkProfile.setOnClickListener(v -> android.widget.Toast.makeText(this, "Virtual Space is active — no setup needed!", android.widget.Toast.LENGTH_SHORT).show());
        }

        // Nuclear Option
        MaterialButton btnPurge = findViewById(R.id.btn_purge);
        if (btnPurge != null) btnPurge.setOnClickListener(v -> showPurgeConfirmation());
    }

    private void updateWorkProfileStatus() {
        TextView tvWpStatus = findViewById(R.id.tv_work_profile_status);
        if (tvWpStatus != null) {
            if (cloneManager.isWorkProfileActive()) {
                tvWpStatus.setText("✅ Active — 2nd accounts enabled");
                tvWpStatus.setTextColor(getColor(R.color.accent_cyan));
            } else if (cloneManager.isProfileOwner()) {
                tvWpStatus.setText("⚡ Profile Owner — Creating space...");
                tvWpStatus.setTextColor(getColor(R.color.accent_cyan));
            } else {
                tvWpStatus.setText("Not setup — Tap to enable 2nd accounts");
                tvWpStatus.setTextColor(getColor(R.color.text_secondary));
            }
        }
    }

    private void showPurgeConfirmation() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("⚠️ Nuclear Option")
            .setMessage("This will erase ALL clones and data. Irreversible.\n\nAre you sure?")
            .setPositiveButton("PURGE EVERYTHING", (d, w) -> {
                cloneManager.purgeAll();
                prefsManager.clearAll();
                Toast.makeText(this, "Environment purged.", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(this, SplashActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_settings);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) { startActivity(new Intent(this, MainActivity.class)); finish(); return true; }
            else if (id == R.id.nav_add) { startActivity(new Intent(this, AddCloneActivity.class)); return true; }
            else if (id == R.id.nav_locker) { startActivity(new Intent(this, LockerActivity.class)); return true; }
            else if (id == R.id.nav_settings) return true;
            return false;
        });
    }
}
