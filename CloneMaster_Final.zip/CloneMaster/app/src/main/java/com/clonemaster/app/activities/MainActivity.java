package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.CloneAdapter;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CloneAdapter.CloneClickListener {

    private CloneAdapter cloneAdapter;
    private CloneManager cloneManager;
    private TextView tvAllocated;
    // Empty state — jab koi clone nahi hoga
    private View emptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cloneManager = CloneManager.getInstance(this);
        setupViews();
        setupBottomNav();

        // Jab CloneManager ka background load complete ho, turant UI refresh karo
        cloneManager.setOnLoadCompleteListener(this::refreshClones);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Agar load already complete hai toh refresh karo
        if (cloneManager != null && cloneManager.isLoadComplete()) {
            refreshClones();
        }
    }

    private void setupViews() {
        tvAllocated = findViewById(R.id.tv_allocated);
        emptyState = findViewById(R.id.empty_state);

        TextView tvSecureSpaceLabel = findViewById(R.id.tv_secure_space_label);
        if (tvSecureSpaceLabel != null) {
            tvSecureSpaceLabel.setText("SECURE SPACE ACTIVE — VIRTUAL DUAL ACCOUNT");
        }

        // Deploy card
        MaterialCardView deployCard = findViewById(R.id.card_deploy);
        if (deployCard != null) {
            deployCard.setOnClickListener(v ->
                startActivity(new Intent(this, AddCloneActivity.class))
            );
        }

        // Avatar → Settings
        View ivAvatar = findViewById(R.id.iv_avatar);
        if (ivAvatar != null) {
            ivAvatar.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class))
            );
        }

        // RecyclerView — 2 column grid
        RecyclerView recyclerView = findViewById(R.id.rv_clones);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
            recyclerView.setHasFixedSize(false);
            cloneAdapter = new CloneAdapter(this, this);
            recyclerView.setAdapter(cloneAdapter);
        }
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) return true;
            if (id == R.id.nav_add) {
                startActivity(new Intent(this, AddCloneActivity.class));
                return true;
            }
            if (id == R.id.nav_locker) {
                startActivity(new Intent(this, LockerActivity.class));
                return true;
            }
            if (id == R.id.nav_settings) {
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }

    private void refreshClones() {
        if (cloneAdapter == null || cloneManager == null) return;
        List<CloneInstance> clones = cloneManager.getCloneInstances();
        cloneAdapter.updateClones(clones);

        int count = clones.size();
        if (tvAllocated != null) tvAllocated.setText(count + " Allocated");

        // Empty state toggle — deploy card bhi show/hide karo accordingly
        View deployCard = findViewById(R.id.card_deploy);
        if (count > 0) {
            if (deployCard != null) deployCard.setVisibility(View.VISIBLE);
            if (emptyState != null) emptyState.setVisibility(View.GONE);
        } else {
            if (deployCard != null) deployCard.setVisibility(View.VISIBLE);
            if (emptyState != null) emptyState.setVisibility(View.GONE);
        }
    }

    @Override
    public void onCloneClick(CloneInstance clone) {
        boolean launched = cloneManager.launchClone(clone);
        if (!launched) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("App Not Installed")
                .setMessage(clone.getAppName() + " is not installed on this device.")
                .setPositiveButton("OK", null)
                .show();
        }
    }

    @Override
    public void onCloneLongClick(CloneInstance clone) {
        String hibernateLabel = clone.isHibernated() ? "Wake Up" : "Hibernate";
        String[] options = {"Launch", hibernateLabel, "Remove"};

        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(clone.getAppName())
            .setItems(options, (dialog, which) -> {
                if (which == 0) {
                    cloneManager.launchClone(clone);
                } else if (which == 1) {
                    if (clone.isHibernated()) cloneManager.wakeClone(clone);
                    else cloneManager.hibernateClone(clone);
                    refreshClones();
                } else {
                    new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Remove Clone")
                        .setMessage("Remove " + clone.getAppName() + " clone?")
                        .setPositiveButton("Remove", (d, w) -> {
                            cloneManager.removeClone(clone.getId());
                            refreshClones();
                            Toast.makeText(this, "Clone removed", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                }
            }).show();
    }
}
