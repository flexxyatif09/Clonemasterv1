package com.clonemaster.app.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class AddCloneActivity extends AppCompatActivity implements AppListAdapter.AppClickListener {

    private AppListAdapter adapter;
    private CloneManager cloneManager;
    private List<AppInfo> allApps = new ArrayList<>();
    private String currentFilter = "All Apps";
    private EditText etSearch;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private boolean isLoading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clone);

        try {
            cloneManager = CloneManager.getInstance(this);
            setupViews();
            loadApps();
        } catch (Exception e) {
            Toast.makeText(this, "Error loading: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void setupViews() {
        // Back button
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // Hide work profile banner — non-root mode mein nahi chahiye
        View banner = findViewById(R.id.banner_work_profile);
        if (banner != null) banner.setVisibility(View.GONE);

        // Search
        etSearch = findViewById(R.id.et_search);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (!isLoading) filterApps(s.toString(), currentFilter);
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        // Category chips
        ChipGroup chipGroup = findViewById(R.id.chip_group);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
                if (!checkedIds.isEmpty()) {
                    Chip chip = group.findViewById(checkedIds.get(0));
                    if (chip != null) {
                        currentFilter = chip.getText().toString();
                        if (!isLoading) filterApps(
                            etSearch != null ? etSearch.getText().toString() : "",
                            currentFilter
                        );
                    }
                }
            });
        }

        // RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rv_apps);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setHasFixedSize(true);
            adapter = new AppListAdapter(this, this);
            recyclerView.setAdapter(adapter);
        }
    }

    private void loadApps() {
        isLoading = true;

        // Background thread mein apps load karo — UI thread block na ho
        new Thread(() -> {
            try {
                List<AppInfo> apps = cloneManager.getInstalledApps();

                // Main thread pe UI update karo
                runOnUiThread(() -> {
                    isLoading = false;
                    allApps = apps != null ? apps : new ArrayList<>();
                    filterApps("", "All Apps");
                });

            } catch (Exception e) {
                runOnUiThread(() -> {
                    isLoading = false;
                    Toast.makeText(this,
                        "Could not load apps: " + e.getMessage(),
                        Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void filterApps(String query, String category) {
        if (adapter == null) return;

        List<AppInfo> filtered = new ArrayList<>();
        for (AppInfo app : allApps) {
            boolean matchesQuery = query.isEmpty()
                || app.getAppName().toLowerCase().contains(query.toLowerCase())
                || app.getPackageName().toLowerCase().contains(query.toLowerCase());
            boolean matchesCategory = category.equals("All Apps")
                || app.getCategory().equalsIgnoreCase(category);
            if (matchesQuery && matchesCategory) filtered.add(app);
        }
        adapter.updateApps(filtered, cloneManager);
    }

    @Override
    public void onAppAdd(AppInfo appInfo) {
        if (appInfo == null) return;

        try {
            if (cloneManager.isAlreadyCloned(appInfo.getPackageName())) {
                Toast.makeText(this,
                    appInfo.getAppName() + " is already cloned!",
                    Toast.LENGTH_SHORT).show();
                return;
            }

            CloneInstance clone = cloneManager.addClone(appInfo);
            Toast.makeText(this,
                "✓ " + appInfo.getAppName() + " added to Clone Space!",
                Toast.LENGTH_LONG).show();

            if (adapter != null) adapter.notifyDataSetChanged();
            finish();

        } catch (Exception e) {
            Toast.makeText(this,
                "Failed to add clone: " + e.getMessage(),
                Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
