package com.clonemaster.app.activities;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.utils.CloneManager;
import com.clonemaster.app.models.AppInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AddCloneActivity — bilkul safe version.
 * Koi XML layout nahi — pure Java se UI bana raha hai.
 * Isse layout inflate crash impossible hai.
 */
public class AddCloneActivity extends AppCompatActivity {

    private LinearLayout appListContainer;
    private ProgressBar progressBar;
    private TextView tvStatus;
    private CloneManager cloneManager;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            cloneManager = CloneManager.getInstance(this);
            buildUI();
            loadApps();
        } catch (Exception e) {
            // Kuch bhi crash kare — simple message dikhao
            TextView tv = new TextView(this);
            tv.setText("Error: " + e.getMessage());
            tv.setTextColor(0xFFFF0000);
            tv.setPadding(40, 40, 40, 40);
            setContentView(tv);
        }
    }

    private void buildUI() {
        // Root — dark background
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0D0D1A);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // Main vertical layout
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        // Top bar
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(16), dp(16), dp(16), dp(16));
        topBar.setBackgroundColor(0xFF0D0D1A);

        TextView btnBack = new TextView(this);
        btnBack.setText("←");
        btnBack.setTextColor(0xFFFFFFFF);
        btnBack.setTextSize(22);
        btnBack.setPadding(dp(8), dp(8), dp(16), dp(8));
        btnBack.setOnClickListener(v -> finish());
        topBar.addView(btnBack);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Select App to Clone");
        tvTitle.setTextColor(0xFF00E5FF);
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        topBar.addView(tvTitle);

        main.addView(topBar);

        // Status text
        tvStatus = new TextView(this);
        tvStatus.setText("Loading apps...");
        tvStatus.setTextColor(0xFF888888);
        tvStatus.setTextSize(13);
        tvStatus.setPadding(dp(20), dp(4), dp(20), dp(4));
        main.addView(tvStatus);

        // Progress bar
        progressBar = new ProgressBar(this);
        LinearLayout.LayoutParams pbParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pbParams.gravity = Gravity.CENTER_HORIZONTAL;
        pbParams.topMargin = dp(20);
        progressBar.setLayoutParams(pbParams);
        progressBar.setIndeterminateTintList(
                android.content.res.ColorStateList.valueOf(0xFF00E5FF));
        main.addView(progressBar);

        // Scrollable app list
        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams svParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollView.setLayoutParams(svParams);

        appListContainer = new LinearLayout(this);
        appListContainer.setOrientation(LinearLayout.VERTICAL);
        appListContainer.setPadding(dp(12), dp(8), dp(12), dp(16));
        scrollView.addView(appListContainer);
        main.addView(scrollView);

        root.addView(main);
        setContentView(root);
    }

    private void loadApps() {
        executor.execute(() -> {
            List<AppInfo> apps = new ArrayList<>();
            String errorMsg = null;

            try {
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> installed = pm.getInstalledApplications(0);

                for (ApplicationInfo info : installed) {
                    try {
                        if (info.packageName.equals(getPackageName())) continue;
                        if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;

                        String name = pm.getApplicationLabel(info).toString();
                        apps.add(new AppInfo(name, info.packageName, null, 0,
                                getCategory(info.packageName)));
                    } catch (Exception ignored) {}
                }

                apps.sort((a, b) ->
                        a.getAppName().compareToIgnoreCase(b.getAppName()));

            } catch (Exception e) {
                errorMsg = e.getMessage();
            }

            final List<AppInfo> result = apps;
            final String finalError = errorMsg;

            mainHandler.post(() -> {
                try {
                    progressBar.setVisibility(View.GONE);

                    if (finalError != null) {
                        tvStatus.setText("Error loading apps: " + finalError);
                        tvStatus.setTextColor(0xFFFF4444);
                        return;
                    }

                    tvStatus.setText(result.size() + " apps found — tap to clone");
                    tvStatus.setTextColor(0xFF00E5FF);

                    if (result.isEmpty()) {
                        TextView empty = new TextView(AddCloneActivity.this);
                        empty.setText("Koi app nahi mila.\nQUERY_ALL_PACKAGES permission check karo.");
                        empty.setTextColor(0xFF888888);
                        empty.setTextSize(14);
                        empty.setGravity(Gravity.CENTER);
                        empty.setPadding(dp(20), dp(40), dp(20), dp(40));
                        appListContainer.addView(empty);
                        return;
                    }

                    for (AppInfo app : result) {
                        appListContainer.addView(buildAppRow(app));
                    }
                } catch (Exception e) {
                    tvStatus.setText("UI error: " + e.getMessage());
                    tvStatus.setTextColor(0xFFFF4444);
                }
            });
        });
    }

    private View buildAppRow(AppInfo app) {
        // Row container
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));
        row.setBackgroundColor(0xFF1A1A2E);

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = dp(6);
        row.setLayoutParams(rowParams);

        // Icon
        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(44), dp(44));
        icon.setLayoutParams(iconParams);
        icon.setImageResource(android.R.drawable.sym_def_app_icon);

        // Load icon in background
        String pkg = app.getPackageName();
        executor.execute(() -> {
            try {
                Drawable d = getPackageManager().getApplicationIcon(pkg);
                mainHandler.post(() -> {
                    try { icon.setImageDrawable(d); } catch (Exception ignored) {}
                });
            } catch (Exception ignored) {}
        });

        row.addView(icon);

        // App name + package
        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        textParams.leftMargin = dp(14);
        textCol.setLayoutParams(textParams);

        TextView tvName = new TextView(this);
        tvName.setText(app.getAppName());
        tvName.setTextColor(0xFFFFFFFF);
        tvName.setTextSize(15);
        tvName.setSingleLine(true);
        tvName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textCol.addView(tvName);

        TextView tvPkg = new TextView(this);
        tvPkg.setText(app.getCategory());
        tvPkg.setTextColor(0xFF666688);
        tvPkg.setTextSize(11);
        textCol.addView(tvPkg);

        row.addView(textCol);

        // Add button
        TextView btnAdd = new TextView(this);
        btnAdd.setText("+ Clone");
        btnAdd.setTextColor(0xFF000000);
        btnAdd.setBackgroundColor(0xFF00E5FF);
        btnAdd.setTextSize(12);
        btnAdd.setPadding(dp(14), dp(8), dp(14), dp(8));
        btnAdd.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

        boolean alreadyCloned = cloneManager != null
                && cloneManager.isAlreadyCloned(app.getPackageName());

        if (alreadyCloned) {
            btnAdd.setText("✓ Added");
            btnAdd.setBackgroundColor(0xFF333355);
            btnAdd.setTextColor(0xFF888888);
        } else {
            btnAdd.setOnClickListener(v -> {
                try {
                    cloneManager.addClone(app);
                    Toast.makeText(this,
                            "✓ " + app.getAppName() + " cloned!",
                            Toast.LENGTH_SHORT).show();
                    finish();
                } catch (Exception e) {
                    Toast.makeText(this,
                            "Error: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        row.addView(btnAdd);
        return row;
    }

    private String getCategory(String pkg) {
        pkg = pkg.toLowerCase();
        if (pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("instagram")
                || pkg.contains("facebook") || pkg.contains("twitter") || pkg.contains("snapchat"))
            return "Social";
        if (pkg.contains("game")) return "Games";
        if (pkg.contains("gmail") || pkg.contains("mail") || pkg.contains("slack")) return "Work";
        if (pkg.contains("bank") || pkg.contains("pay") || pkg.contains("paytm")) return "Finance";
        return "Other";
    }

    private int dp(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
