package com.clonemaster.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AddCloneActivity extends AppCompatActivity implements AppListAdapter.AppClickListener {

    private AppListAdapter adapter;
    private CloneManager cloneManager;
    private List<AppInfo> allApps = new ArrayList<>();
    private String currentFilter = "All Apps";
    private EditText etSearch;
    private ProgressBar progressBar;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clone);
        cloneManager = CloneManager.getInstance(this);
        setupViews();
        loadApps();
    }

    private void setupViews() {
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // Banner hide karo
        View banner = findViewById(R.id.banner_work_profile);
        if (banner != null) banner.setVisibility(View.GONE);

        // Search
        etSearch = findViewById(R.id.et_search);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
                @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                    filterApps(s.toString(), currentFilter);
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        // Chips
        ChipGroup chipGroup = findViewById(R.id.chip_group);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, ids) -> {
                if (!ids.isEmpty()) {
                    Chip chip = group.findViewById(ids.get(0));
                    if (chip != null) {
                        currentFilter = chip.getText().toString();
                        filterApps(etSearch != null ? etSearch.getText().toString() : "", currentFilter);
                    }
                }
            });
        }

        // RecyclerView
        RecyclerView rv = findViewById(R.id.rv_apps);
        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
            rv.setHasFixedSize(true);
            adapter = new AppListAdapter(this, this);
            rv.setAdapter(adapter);
        }
    }

    private void loadApps() {
        // Background thread mein load karo
        executor.execute(() -> {
            try {
                // Sirf USER-installed apps lo — system apps skip karo (fast hoga)
                android.content.pm.PackageManager pm = getPackageManager();
                List<android.content.pm.ApplicationInfo> installed =
                    pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA);

                List<AppInfo> apps = new ArrayList<>();
                for (android.content.pm.ApplicationInfo info : installed) {
                    // Sirf launchable + non-system apps
                    if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;
                    if (info.packageName.equals(getPackageName())) continue;
                    // System apps skip karo
                    if ((info.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) continue;

                    try {
                        String name = pm.getApplicationLabel(info).toString();
                        long size = 0;
                        try { size = new java.io.File(info.sourceDir).length(); } catch (Exception ignored) {}
                        String category = getCategory(info.packageName, name);
                        apps.add(new AppInfo(name, info.packageName,
                            pm.getApplicationIcon(info), size, category));
                    } catch (Exception ignored) {}
                }

                // Sort
                apps.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));

                // UI update — main thread pe
                mainHandler.post(() -> {
                    allApps = apps;
                    filterApps("", "All Apps");
                    if (apps.isEmpty()) {
                        Toast.makeText(this, "No user apps found", Toast.LENGTH_SHORT).show();
                    }
                });

            } catch (Exception e) {
                mainHandler.post(() ->
                    Toast.makeText(this, "Load error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    private void filterApps(String query, String category) {
        if (adapter == null) return;
        List<AppInfo> filtered = new ArrayList<>();
        for (AppInfo app : allApps) {
            boolean matchQuery = query.isEmpty()
                || app.getAppName().toLowerCase().contains(query.toLowerCase())
                || app.getPackageName().toLowerCase().contains(query.toLowerCase());
            boolean matchCat = category.equals("All Apps")
                || app.getCategory().equalsIgnoreCase(category);
            if (matchQuery && matchCat) filtered.add(app);
        }
        adapter.updateApps(filtered, cloneManager);
    }

    @Override
    public void onAppAdd(AppInfo appInfo) {
        if (cloneManager.isAlreadyCloned(appInfo.getPackageName())) {
            Toast.makeText(this, appInfo.getAppName() + " already cloned!", Toast.LENGTH_SHORT).show();
            return;
        }
        cloneManager.addClone(appInfo);
        Toast.makeText(this, "✓ " + appInfo.getAppName() + " added!", Toast.LENGTH_SHORT).show();
        if (adapter != null) adapter.notifyDataSetChanged();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    private String getCategory(String pkg, String name) {
        pkg = pkg.toLowerCase(); name = name.toLowerCase();
        if (pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("instagram")
            || pkg.contains("facebook") || pkg.contains("twitter") || pkg.contains("tiktok")
            || name.contains("chat") || name.contains("message")) return "Social";
        if (pkg.contains("game") || name.contains("game")) return "Games";
        if (pkg.contains("gmail") || pkg.contains("mail") || pkg.contains("office")) return "Work";
        if (pkg.contains("bank") || pkg.contains("pay") || pkg.contains("wallet")) return "Finance";
        return "System";
    }
}
