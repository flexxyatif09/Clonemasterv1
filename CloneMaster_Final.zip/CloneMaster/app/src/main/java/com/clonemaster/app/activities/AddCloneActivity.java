package com.clonemaster.app.activities;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class AddCloneActivity extends AppCompatActivity implements AppListAdapter.AppClickListener {

    private AppListAdapter adapter;
    private CloneManager cloneManager;
    private List<AppInfo> allApps = new ArrayList<>();
    private String currentFilter = "All Apps";
    private String currentQuery = "";
    private EditText etSearch;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // Activity destroy ho jaye toh background task UI touch na kare
    private final AtomicBoolean isDestroyed = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clone);

        cloneManager = CloneManager.getInstance(this);
        setupViews();
        loadApps();
    }

    private void setupViews() {
        // Back button
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // Banner hide
        View banner = findViewById(R.id.banner_work_profile);
        if (banner != null) banner.setVisibility(View.GONE);

        // ProgressBar aur empty state
        progressBar = findViewById(R.id.progress_bar);
        tvEmpty = findViewById(R.id.tv_empty);

        // Search
        etSearch = findViewById(R.id.et_search);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
                @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                    currentQuery = s.toString();
                    filterAndShow();
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        // Category Chips
        ChipGroup chipGroup = findViewById(R.id.chip_group);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, ids) -> {
                if (!ids.isEmpty()) {
                    Chip chip = group.findViewById(ids.get(0));
                    if (chip != null) {
                        currentFilter = chip.getText().toString();
                        filterAndShow();
                    }
                }
            });
        }

        // RecyclerView
        RecyclerView rv = findViewById(R.id.rv_apps);
        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
            rv.setHasFixedSize(true);
            // Item reuse optimization
            rv.setRecycledViewPool(new RecyclerView.RecycledViewPool());
            adapter = new AppListAdapter(this, this);
            rv.setAdapter(adapter);
        }
    }

    private void loadApps() {
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        if (tvEmpty != null) tvEmpty.setVisibility(View.GONE);

        executor.execute(() -> {
            try {
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> installed =
                    pm.getInstalledApplications(PackageManager.GET_META_DATA);

                List<AppInfo> apps = new ArrayList<>();

                for (ApplicationInfo info : installed) {
                    if (isDestroyed.get()) return; // Activity gone, kaam band karo

                    // Only launchable user apps
                    if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;
                    if (info.packageName.equals(getPackageName())) continue;
                    if ((info.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;

                    try {
                        String name = pm.getApplicationLabel(info).toString();
                        long size = 0;
                        try { size = new java.io.File(info.sourceDir).length(); } catch (Exception ignored) {}

                        // Icon safely load karo
                        Drawable icon;
                        try {
                            icon = pm.getApplicationIcon(info.packageName);
                        } catch (PackageManager.NameNotFoundException e) {
                            icon = pm.getDefaultActivityIcon();
                        }

                        String category = getCategory(info.packageName, name);
                        apps.add(new AppInfo(name, info.packageName, icon, size, category));

                    } catch (Exception ignored) {}
                }

                // Alphabetically sort
                apps.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));

                if (!isDestroyed.get()) {
                    mainHandler.post(() -> {
                        if (isDestroyed.get()) return;
                        allApps = apps;
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                        filterAndShow();
                    });
                }

            } catch (Exception e) {
                if (!isDestroyed.get()) {
                    mainHandler.post(() -> {
                        if (isDestroyed.get()) return;
                        if (progressBar != null) progressBar.setVisibility(View.GONE);
                        Toast.makeText(AddCloneActivity.this,
                            "Could not load apps", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void filterAndShow() {
        if (adapter == null) return;

        List<AppInfo> filtered = new ArrayList<>();
        String query = currentQuery.toLowerCase().trim();

        for (AppInfo app : allApps) {
            boolean matchQuery = query.isEmpty()
                || app.getAppName().toLowerCase().contains(query)
                || app.getPackageName().toLowerCase().contains(query);
            boolean matchCat = currentFilter.equals("All Apps")
                || app.getCategory().equalsIgnoreCase(currentFilter);
            if (matchQuery && matchCat) filtered.add(app);
        }

        adapter.updateApps(filtered, cloneManager);

        // Empty state
        if (tvEmpty != null) {
            tvEmpty.setVisibility(filtered.isEmpty() && !allApps.isEmpty() ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public void onAppAdd(AppInfo appInfo) {
        if (cloneManager == null) return;
        if (cloneManager.isAlreadyCloned(appInfo.getPackageName())) {
            Toast.makeText(this, appInfo.getAppName() + " already added!", Toast.LENGTH_SHORT).show();
            return;
        }
        cloneManager.addClone(appInfo);
        Toast.makeText(this, "✓ " + appInfo.getAppName() + " added!", Toast.LENGTH_SHORT).show();
        if (adapter != null) adapter.notifyDataSetChanged();
        finish();
    }

    @Override
    protected void onDestroy() {
        isDestroyed.set(true); // Background thread ko signal
        mainHandler.removeCallbacksAndMessages(null); // Pending UI updates cancel
        executor.shutdownNow();
        super.onDestroy();
    }

    private String getCategory(String pkg, String name) {
        pkg = pkg.toLowerCase();
        name = name.toLowerCase();
        if (pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("instagram")
            || pkg.contains("facebook") || pkg.contains("twitter") || pkg.contains("tiktok")
            || name.contains("chat") || name.contains("message")) return "Social";
        if (pkg.contains("game") || name.contains("game")) return "Games";
        if (pkg.contains("gmail") || pkg.contains("mail") || pkg.contains("office")) return "Work";
        if (pkg.contains("bank") || pkg.contains("pay") || pkg.contains("wallet")) return "Finance";
        return "Other";
    }
}
