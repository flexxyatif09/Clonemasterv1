package com.clonemaster.app.activities;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class AddCloneActivity extends AppCompatActivity implements AppListAdapter.AppClickListener {

    private AppListAdapter adapter;
    private CloneManager cloneManager;
    private List<AppInfo> allApps = new ArrayList<>();
    private String currentFilter = "All Apps";
    private String currentQuery = "";
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private EditText etSearch;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean destroyed = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clone);
        cloneManager = CloneManager.getInstance(this);
        setupViews();
        loadApps();
    }

    private void setupViews() {
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        progressBar = findViewById(R.id.progress_bar);
        tvEmpty = findViewById(R.id.tv_empty);

        etSearch = findViewById(R.id.et_search);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
                @Override public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                    currentQuery = s.toString();
                    filterAndShow();
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        ChipGroup chipGroup = findViewById(R.id.chip_group);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, ids) -> {
                if (!ids.isEmpty()) {
                    Chip chip = group.findViewById(ids.get(0));
                    if (chip != null) {
                        currentFilter = chip.getText().toString();
                        filterAndShow();
                    }
                }
            });
        }

        RecyclerView rv = findViewById(R.id.rv_apps);
        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
            rv.setHasFixedSize(true);
            adapter = new AppListAdapter(this, this);
            rv.setAdapter(adapter);
        }
    }

    private void loadApps() {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        if (tvEmpty != null) tvEmpty.setVisibility(View.GONE);

        executor.execute(() -> {
            List<AppInfo> apps = new ArrayList<>();
            try {
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> installed =
                    pm.getInstalledApplications(0); // 0 = fastest, no extra meta

                for (ApplicationInfo info : installed) {
                    if (destroyed.get()) return;

                    // Skip self
                    if (info.packageName.equals(getPackageName())) continue;

                    // Must be launchable
                    if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;

                    // Skip pure system apps — but keep updated ones (WhatsApp, Instagram etc)
                    boolean isPureSystem = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                            && (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                    if (isPureSystem) continue;

                    try {
                        String name = pm.getApplicationLabel(info).toString();
                        long size = 0;
                        try { size = new java.io.File(info.sourceDir).length(); } catch (Exception ignored) {}
                        String category = getCategory(info.packageName, name);

                        // Icon null rakho — AppListAdapter Glide se load karega
                        apps.add(new AppInfo(name, info.packageName, null, size, category));
                    } catch (Exception ignored) {}
                }

                apps.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));

            } catch (Exception e) {
                // ignore
            }

            if (!destroyed.get()) {
                final List<AppInfo> result = apps;
                mainHandler.post(() -> {
                    if (destroyed.get()) return;
                    allApps = result;
                    if (progressBar != null) progressBar.setVisibility(View.GONE);
                    filterAndShow();
                    if (result.isEmpty()) {
                        if (tvEmpty != null) tvEmpty.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

    private void filterAndShow() {
        if (adapter == null) return;
        List<AppInfo> filtered = new ArrayList<>();
        String q = currentQuery.toLowerCase().trim();
        for (AppInfo app : allApps) {
            boolean matchQ = q.isEmpty()
                || app.getAppName().toLowerCase().contains(q)
                || app.getPackageName().toLowerCase().contains(q);
            boolean matchCat = currentFilter.equals("All Apps")
                || app.getCategory().equalsIgnoreCase(currentFilter);
            if (matchQ && matchCat) filtered.add(app);
        }
        adapter.updateApps(filtered, cloneManager);
        if (tvEmpty != null) {
            tvEmpty.setVisibility(
                filtered.isEmpty() && !allApps.isEmpty() ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public void onAppAdd(AppInfo appInfo) {
        if (cloneManager == null) return;
        if (cloneManager.isAlreadyCloned(appInfo.getPackageName())) {
            Toast.makeText(this, appInfo.getAppName() + " already added!", Toast.LENGTH_SHORT).show();
            return;
        }
        cloneManager.addClone(appInfo);
        Toast.makeText(this, "✓ " + appInfo.getAppName() + " cloned!", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    protected void onDestroy() {
        destroyed.set(true);
        mainHandler.removeCallbacksAndMessages(null);
        executor.shutdownNow();
        super.onDestroy();
    }

    private String getCategory(String pkg, String name) {
        pkg = pkg.toLowerCase(); name = name.toLowerCase();
        if (pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("instagram")
            || pkg.contains("facebook") || pkg.contains("twitter") || pkg.contains("tiktok")
            || pkg.contains("snapchat") || pkg.contains("signal")
            || name.contains("chat") || name.contains("message")) return "Social";
        if (pkg.contains("game") || name.contains("game")) return "Games";
        if (pkg.contains("gmail") || pkg.contains("mail") || pkg.contains("office")
            || pkg.contains("outlook") || pkg.contains("slack")) return "Work";
        if (pkg.contains("bank") || pkg.contains("pay") || pkg.contains("wallet")
            || pkg.contains("phonepe") || pkg.contains("gpay") || pkg.contains("paytm")) return "Finance";
        return "Other";
    }
}
