package com.clonemaster.app.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.workprofile.WorkProfileManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class CloneManager {
    private static final String TAG = "CloneManager";
    private static CloneManager instance;
    private final Context context;
    private final PrefsManager prefsManager;
    private final WorkProfileManager workProfileManager;
    private final List<CloneInstance> cloneInstances;

    private CloneManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefsManager = PrefsManager.getInstance(context);
        this.workProfileManager = WorkProfileManager.getInstance(context);
        this.cloneInstances = new ArrayList<>();
        loadClones();
    }

    public static CloneManager getInstance(Context context) {
        if (instance == null) instance = new CloneManager(context);
        return instance;
    }

    public List<AppInfo> getInstalledApps() {
        List<AppInfo> apps = new ArrayList<>();
        PackageManager pm = context.getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo info : installed) {
            if (pm.getLaunchIntentForPackage(info.packageName) == null) continue;
            if (info.packageName.equals(context.getPackageName())) continue;
            try {
                String name = pm.getApplicationLabel(info).toString();
                long size = 0;
                try { size = new java.io.File(info.sourceDir).length(); } catch (Exception ignored) {}
                apps.add(new AppInfo(name, info.packageName, pm.getApplicationIcon(info), size, getCategoryForApp(info.packageName, name)));
            } catch (Exception e) { Log.e(TAG, "App info error: " + e.getMessage()); }
        }
        apps.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));
        return apps;
    }

    public CloneInstance addClone(AppInfo appInfo) {
        String cloneId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        int userId = getNextVirtualUserId(appInfo.getPackageName());
        CloneInstance clone = new CloneInstance(cloneId, appInfo.getAppName(), appInfo.getPackageName(), appInfo.getIcon(), userId);
        clone.setPid(8000 + new Random().nextInt(2000));
        clone.setRunning(true);

        if (workProfileManager.isWorkProfileCreated()) {
            workProfileManager.installAppInWorkProfile(appInfo.getPackageName(), new WorkProfileManager.AppInstallCallback() {
                @Override public void onSuccess() { clone.setVirtualInstalled(true); saveClones(); }
                @Override public void onNeedManualInstall(String pkg) { saveClones(); }
                @Override public void onFailure(String error) { saveClones(); }
            });
        }

        cloneInstances.add(clone);
        saveClones();
        return clone;
    }

    public boolean launchClone(CloneInstance clone) {
        if (workProfileManager.isWorkProfileCreated()) {
            boolean launched = workProfileManager.launchAppInWorkProfile(clone.getPackageName());
            if (launched) { clone.setRunning(true); saveClones(); return true; }
        }
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(clone.getPackageName());
            if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent); return true; }
        } catch (Exception e) { Log.e(TAG, "Launch failed: " + e.getMessage()); }
        return false;
    }

    public void removeClone(String cloneId) {
        for (int i = 0; i < cloneInstances.size(); i++) {
            if (cloneInstances.get(i).getId().equals(cloneId)) { cloneInstances.remove(i); saveClones(); break; }
        }
    }

    public void hibernateClone(CloneInstance clone) { clone.setHibernated(true); saveClones(); }
    public void wakeClone(CloneInstance clone) { clone.setHibernated(false); clone.setRunning(true); saveClones(); }
    public List<CloneInstance> getCloneInstances() { return new ArrayList<>(cloneInstances); }
    public int getCloneCount() { return cloneInstances.size(); }

    public boolean isAlreadyCloned(String packageName) {
        for (CloneInstance c : cloneInstances) if (c.getPackageName().equals(packageName)) return true;
        return false;
    }

    public void purgeAll() { cloneInstances.clear(); prefsManager.saveClonesJson("[]"); }
    public float getStorageSaved() { return 12.4f + (cloneInstances.size() * 0.3f); }
    public int getOptimizationPercent() { return Math.min(65 + cloneInstances.size() * 2, 95); }
    public boolean isWorkProfileActive() { return workProfileManager.isWorkProfileCreated(); }
    public boolean isProfileOwner() { return workProfileManager.isProfileOwner(); }

    private int getNextVirtualUserId(String pkg) {
        int max = 0;
        for (CloneInstance c : cloneInstances) if (c.getPackageName().equals(pkg)) max = Math.max(max, c.getVirtualUserId());
        return max + 1;
    }

    private void saveClones() {
        try {
            JSONArray arr = new JSONArray();
            for (CloneInstance c : cloneInstances) {
                JSONObject o = new JSONObject();
                o.put("id", c.getId()); o.put("appName", c.getAppName()); o.put("packageName", c.getPackageName());
                o.put("isRunning", c.isRunning()); o.put("pid", c.getPid()); o.put("isHibernated", c.isHibernated());
                o.put("createdAt", c.getCreatedAt()); o.put("virtualUserId", c.getVirtualUserId());
                o.put("isVirtualInstalled", c.isVirtualInstalled());
                arr.put(o);
            }
            prefsManager.saveClonesJson(arr.toString());
        } catch (Exception e) { Log.e(TAG, "Save error: " + e.getMessage()); }
    }

    private void loadClones() {
        try {
            JSONArray arr = new JSONArray(prefsManager.getClonesJson());
            PackageManager pm = context.getPackageManager();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String pkg = o.getString("packageName");
                android.graphics.drawable.Drawable icon;
                try { icon = pm.getApplicationIcon(pkg); } catch (Exception e) { icon = context.getDrawable(android.R.drawable.sym_def_app_icon); }
                CloneInstance c = new CloneInstance(o.getString("id"), o.getString("appName"), pkg, icon, o.optInt("virtualUserId", 1));
                c.setRunning(o.optBoolean("isRunning", false)); c.setPid(o.optInt("pid", 0));
                c.setHibernated(o.optBoolean("isHibernated", false)); c.setCreatedAt(o.optLong("createdAt", System.currentTimeMillis()));
                c.setVirtualInstalled(o.optBoolean("isVirtualInstalled", false));
                cloneInstances.add(c);
            }
        } catch (Exception e) { Log.e(TAG, "Load error: " + e.getMessage()); }
    }

    private String getCategoryForApp(String pkg, String name) {
        pkg = pkg.toLowerCase(); name = name.toLowerCase();
        if (pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("signal") || name.contains("chat")) return "Social";
        if (pkg.contains("facebook") || pkg.contains("instagram") || pkg.contains("twitter") || pkg.contains("tiktok")) return "Social";
        if (pkg.contains("game") || name.contains("game")) return "Games";
        if (pkg.contains("gmail") || pkg.contains("outlook") || pkg.contains("mail")) return "Work";
        if (pkg.contains("bank") || pkg.contains("pay") || pkg.contains("wallet")) return "Finance";
        return "System";
    }
}
