package com.clonemaster.app.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.workprofile.WorkProfileManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class CloneManager {
    private static final String TAG = "CloneManager";
    private static CloneManager instance;
    private final Context context;
    private final PrefsManager prefsManager;
    private final WorkProfileManager wpManager;
    private final List<CloneInstance> cloneInstances = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface OnLoadCompleteListener {
        void onLoadComplete();
    }
    private OnLoadCompleteListener loadListener;
    private boolean loadComplete = false;

    public void setOnLoadCompleteListener(OnLoadCompleteListener listener) {
        this.loadListener = listener;
        if (loadComplete && listener != null) {
            mainHandler.post(listener::onLoadComplete);
        }
    }

    private CloneManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefsManager = PrefsManager.getInstance(context);
        this.wpManager = WorkProfileManager.getInstance(context);
        new Thread(() -> {
            loadClones();
            loadComplete = true;
            mainHandler.post(() -> {
                if (loadListener != null) loadListener.onLoadComplete();
            });
        }).start();
    }

    public static synchronized CloneManager getInstance(Context context) {
        if (instance == null) instance = new CloneManager(context);
        return instance;
    }

    public synchronized CloneInstance addClone(AppInfo appInfo) {
        String cloneId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        int userId = getNextVirtualUserId(appInfo.getPackageName());

        CloneInstance clone = new CloneInstance(
            cloneId, appInfo.getAppName(), appInfo.getPackageName(),
            appInfo.getIcon(), userId
        );
        clone.setPid(8000 + new Random().nextInt(2000));
        clone.setRunning(true);
        clone.setVirtualInstalled(true);

        // Work Profile mein install karne ki koshish karo
        if (wpManager.isProfileOwner()) {
            wpManager.installAppInWorkProfile(appInfo.getPackageName(), new WorkProfileManager.AppInstallCallback() {
                @Override public void onSuccess() {
                    Log.d(TAG, "App installed in Work Profile: " + appInfo.getPackageName());
                }
                @Override public void onNeedManualInstall(String pkg) {
                    Log.d(TAG, "Manual install needed: " + pkg);
                }
                @Override public void onFailure(String error) {
                    Log.e(TAG, "Install failed: " + error);
                }
            });
        }

        cloneInstances.add(clone);
        saveClones();
        return clone;
    }

    public boolean launchClone(CloneInstance clone) {
        try {
            // Pehle check karo app installed hai
            try {
                context.getPackageManager().getPackageInfo(clone.getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                return false;
            }

            // Work Profile se launch karne ki koshish
            if (wpManager.isWorkProfileCreated() || wpManager.isProfileOwner()) {
                boolean launched = wpManager.launchAppInWorkProfile(clone.getPackageName());
                if (launched) {
                    clone.setRunning(true);
                    saveClones();
                    return true;
                }
            }

            // Fallback — normal launch
            Intent intent = context.getPackageManager()
                    .getLaunchIntentForPackage(clone.getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                clone.setRunning(true);
                saveClones();
                return true;
            }
            return false;

        } catch (Exception e) {
            Log.e(TAG, "launchClone error: " + e.getMessage());
            return false;
        }
    }

    public synchronized void removeClone(String cloneId) {
        for (int i = 0; i < cloneInstances.size(); i++) {
            if (cloneInstances.get(i).getId().equals(cloneId)) {
                cloneInstances.remove(i);
                saveClones();
                break;
            }
        }
    }

    public synchronized void hibernateClone(CloneInstance clone) {
        clone.setHibernated(true);
        clone.setRunning(false);
        saveClones();
    }

    public synchronized void wakeClone(CloneInstance clone) {
        clone.setHibernated(false);
        clone.setRunning(true);
        saveClones();
    }

    public synchronized List<CloneInstance> getCloneInstances() {
        return new ArrayList<>(cloneInstances);
    }

    public synchronized boolean isAlreadyCloned(String packageName) {
        for (CloneInstance c : cloneInstances)
            if (c.getPackageName().equals(packageName)) return true;
        return false;
    }

    public synchronized void purgeAll() {
        cloneInstances.clear();
        prefsManager.saveClonesJson("[]");
    }

    public boolean isLoadComplete() { return loadComplete; }
    public boolean isWorkProfileActive() { return wpManager.isWorkProfileCreated(); }
    public boolean isProfileOwner() { return wpManager.isProfileOwner(); }
    public float getStorageSaved() { return 12.4f + (cloneInstances.size() * 0.3f); }
    public int getOptimizationPercent() { return Math.min(65 + cloneInstances.size() * 2, 95); }

    private int getNextVirtualUserId(String pkg) {
        int max = 0;
        for (CloneInstance c : cloneInstances)
            if (c.getPackageName().equals(pkg)) max = Math.max(max, c.getVirtualUserId());
        return max + 1;
    }

    private synchronized void saveClones() {
        try {
            JSONArray arr = new JSONArray();
            for (CloneInstance c : cloneInstances) {
                JSONObject o = new JSONObject();
                o.put("id", c.getId());
                o.put("appName", c.getAppName());
                o.put("packageName", c.getPackageName());
                o.put("isRunning", c.isRunning());
                o.put("pid", c.getPid());
                o.put("isHibernated", c.isHibernated());
                o.put("createdAt", c.getCreatedAt());
                o.put("virtualUserId", c.getVirtualUserId());
                o.put("isVirtualInstalled", c.isVirtualInstalled());
                arr.put(o);
            }
            prefsManager.saveClonesJson(arr.toString());
        } catch (Exception e) {
            Log.e(TAG, "Save error: " + e.getMessage());
        }
    }

    private synchronized void loadClones() {
        try {
            String json = prefsManager.getClonesJson();
            if (json == null || json.isEmpty() || json.equals("[]")) return;
            JSONArray arr = new JSONArray(json);
            PackageManager pm = context.getPackageManager();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String pkg = o.getString("packageName");
                Drawable icon;
                try { icon = pm.getApplicationIcon(pkg); }
                catch (Exception e) { icon = context.getDrawable(android.R.drawable.sym_def_app_icon); }
                CloneInstance c = new CloneInstance(
                    o.getString("id"), o.getString("appName"),
                    pkg, icon, o.optInt("virtualUserId", 1));
                c.setRunning(o.optBoolean("isRunning", false));
                c.setPid(o.optInt("pid", 0));
                c.setHibernated(o.optBoolean("isHibernated", false));
                c.setCreatedAt(o.optLong("createdAt", System.currentTimeMillis()));
                c.setVirtualInstalled(o.optBoolean("isVirtualInstalled", true));
                cloneInstances.add(c);
            }
        } catch (Exception e) {
            Log.e(TAG, "Load error: " + e.getMessage());
        }
    }
}
