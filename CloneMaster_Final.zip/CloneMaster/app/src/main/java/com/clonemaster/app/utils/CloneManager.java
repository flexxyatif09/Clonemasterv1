package com.clonemaster.app.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.models.CloneInstance;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class CloneManager {
    private static final String TAG = "CloneManager";
    private static CloneManager instance;
    private final Context context;
    private final PrefsManager prefsManager;
    private final List<CloneInstance> cloneInstances = new ArrayList<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface OnLoadCompleteListener { void onLoadComplete(); }
    private OnLoadCompleteListener loadListener;
    private boolean loadComplete = false;

    public void setOnLoadCompleteListener(OnLoadCompleteListener listener) {
        this.loadListener = listener;
        if (loadComplete && listener != null) mainHandler.post(listener::onLoadComplete);
    }

    private CloneManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefsManager = PrefsManager.getInstance(context);
        new Thread(() -> {
            loadClones();
            loadComplete = true;
            mainHandler.post(() -> { if (loadListener != null) loadListener.onLoadComplete(); });
        }).start();
    }

    public static synchronized CloneManager getInstance(Context context) {
        if (instance == null) instance = new CloneManager(context);
        return instance;
    }

    public synchronized CloneInstance addClone(AppInfo appInfo) {
        String cloneId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        int userId = getNextVirtualUserId(appInfo.getPackageName());
        CloneInstance clone = new CloneInstance(cloneId, appInfo.getAppName(),
                appInfo.getPackageName(), appInfo.getIcon(), userId);
        clone.setPid(8000 + new Random().nextInt(2000));
        clone.setRunning(true);
        clone.setVirtualInstalled(true);
        cloneInstances.add(clone);
        saveClones();
        return clone;
    }

    /**
     * Phone brand detect karke us brand ki clone setting kholo
     */
    public boolean launchClone(CloneInstance clone) {
        try {
            String brand = Build.MANUFACTURER.toLowerCase();
            String pkg = clone.getPackageName();

            // Phone brand ke hisaab se seedha clone setting kholo
            if (brand.contains("infinix") || brand.contains("tecno") || brand.contains("itel")) {
                if (openInfinixCloneSetting(pkg)) return true;
            } else if (brand.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco")) {
                if (openXiaomiDualApp(pkg)) return true;
            } else if (brand.contains("samsung")) {
                if (openSamsungDualMessenger(pkg)) return true;
            } else if (brand.contains("oppo") || brand.contains("realme") || brand.contains("oneplus")) {
                if (openOppoCloneApp(pkg)) return true;
            } else if (brand.contains("vivo") || brand.contains("iqoo")) {
                if (openVivoCloneApp(pkg)) return true;
            } else if (brand.contains("huawei") || brand.contains("honor")) {
                if (openHuaweiTwinApp(pkg)) return true;
            }

            // Koi brand match nahi — generic settings kholo
            return openGenericCloneSetting(pkg);

        } catch (Exception e) {
            Log.e(TAG, "launchClone error: " + e.getMessage());
            return false;
        }
    }

    // ===== INFINIX / TECNO =====
    private boolean openInfinixCloneSetting(String pkg) {
        // Infinix HiOS — App Clone setting
        String[] intents = {
            "com.transsion.cloneapp",
            "com.infinix.cloneapp",
            "com.hios.cloneapp"
        };
        for (String action : intents) {
            try {
                Intent i = context.getPackageManager().getLaunchIntentForPackage(action);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                    return true;
                }
            } catch (Exception ignored) {}
        }
        // Deep link try karo
        try {
            Intent i = new Intent("com.transsion.cloneapp.action.OPEN");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra("package", pkg);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== XIAOMI / REDMI / POCO =====
    private boolean openXiaomiDualApp(String pkg) {
        try {
            // MIUI Dual Apps deep link
            Intent i = new Intent();
            i.setClassName("com.miui.securitycenter",
                    "com.miui.permcenter.privacymanager.DualAppsDetailActivity");
            i.putExtra("package_name", pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        try {
            // Fallback — MIUI Dual Apps main screen
            Intent i = new Intent();
            i.setClassName("com.miui.securitycenter",
                    "com.miui.permcenter.privacymanager.DualAppsActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== SAMSUNG =====
    private boolean openSamsungDualMessenger(String pkg) {
        try {
            Intent i = new Intent();
            i.setClassName("com.samsung.android.setting.multisound",
                    "com.samsung.android.setting.multisound.DualMessengerActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        try {
            // Samsung One UI 4+
            Intent i = new Intent("android.settings.DUAL_SIM_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== OPPO / REALME / ONEPLUS =====
    private boolean openOppoCloneApp(String pkg) {
        try {
            Intent i = new Intent();
            i.setClassName("com.coloros.cloneapp",
                    "com.coloros.cloneapp.MainCloneActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        try {
            Intent i = new Intent();
            i.setClassName("com.oplus.cloneapp",
                    "com.oplus.cloneapp.CloneAppActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== VIVO / iQOO =====
    private boolean openVivoCloneApp(String pkg) {
        try {
            Intent i = new Intent();
            i.setClassName("com.vivo.easyshare",
                    "com.vivo.easyshare.ui.CloneAppListActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== HUAWEI / HONOR =====
    private boolean openHuaweiTwinApp(String pkg) {
        try {
            Intent i = new Intent();
            i.setClassName("com.huawei.phonemanager",
                    "com.huawei.phonemanager.appclone.AppCloneActivity");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception ignored) {}
        return openGenericCloneSetting(pkg);
    }

    // ===== GENERIC FALLBACK — Android Settings =====
    private boolean openGenericCloneSetting(String pkg) {
        try {
            // Android App Info page kholo — wahan se user khud dekhe
            Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(android.net.Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public synchronized void removeClone(String cloneId) {
        for (int i = 0; i < cloneInstances.size(); i++) {
            if (cloneInstances.get(i).getId().equals(cloneId)) {
                cloneInstances.remove(i);
                saveClones();
                break;
            }
        }
    }

    public synchronized void hibernateClone(CloneInstance clone) {
        clone.setHibernated(true); clone.setRunning(false); saveClones();
    }

    public synchronized void wakeClone(CloneInstance clone) {
        clone.setHibernated(false); clone.setRunning(true); saveClones();
    }

    public synchronized List<CloneInstance> getCloneInstances() {
        return new ArrayList<>(cloneInstances);
    }

    public synchronized boolean isAlreadyCloned(String packageName) {
        for (CloneInstance c : cloneInstances)
            if (c.getPackageName().equals(packageName)) return true;
        return false;
    }

    public synchronized void purgeAll() {
        cloneInstances.clear();
        prefsManager.saveClonesJson("[]");
    }

    public boolean isLoadComplete() { return loadComplete; }
    public boolean isWorkProfileActive() { return false; }
    public boolean isProfileOwner() { return false; }
    public float getStorageSaved() { return 12.4f + (cloneInstances.size() * 0.3f); }
    public int getOptimizationPercent() { return Math.min(65 + cloneInstances.size() * 2, 95); }

    private int getNextVirtualUserId(String pkg) {
        int max = 0;
        for (CloneInstance c : cloneInstances)
            if (c.getPackageName().equals(pkg)) max = Math.max(max, c.getVirtualUserId());
        return max + 1;
    }

    private synchronized void saveClones() {
        try {
            JSONArray arr = new JSONArray();
            for (CloneInstance c : cloneInstances) {
                JSONObject o = new JSONObject();
                o.put("id", c.getId()); o.put("appName", c.getAppName());
                o.put("packageName", c.getPackageName()); o.put("isRunning", c.isRunning());
                o.put("pid", c.getPid()); o.put("isHibernated", c.isHibernated());
                o.put("createdAt", c.getCreatedAt()); o.put("virtualUserId", c.getVirtualUserId());
                o.put("isVirtualInstalled", c.isVirtualInstalled());
                arr.put(o);
            }
            prefsManager.saveClonesJson(arr.toString());
        } catch (Exception e) { Log.e(TAG, "Save error: " + e.getMessage()); }
    }

    private synchronized void loadClones() {
        try {
            String json = prefsManager.getClonesJson();
            if (json == null || json.isEmpty() || json.equals("[]")) return;
            JSONArray arr = new JSONArray(json);
            PackageManager pm = context.getPackageManager();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String pkg = o.getString("packageName");
                Drawable icon;
                try { icon = pm.getApplicationIcon(pkg); }
                catch (Exception e) { icon = context.getDrawable(android.R.drawable.sym_def_app_icon); }
                CloneInstance c = new CloneInstance(o.getString("id"), o.getString("appName"),
                        pkg, icon, o.optInt("virtualUserId", 1));
                c.setRunning(o.optBoolean("isRunning", false));
                c.setPid(o.optInt("pid", 0));
                c.setHibernated(o.optBoolean("isHibernated", false));
                c.setCreatedAt(o.optLong("createdAt", System.currentTimeMillis()));
                c.setVirtualInstalled(o.optBoolean("isVirtualInstalled", true));
                cloneInstances.add(c);
            }
        } catch (Exception e) { Log.e(TAG, "Load error: " + e.getMessage()); }
    }
}
