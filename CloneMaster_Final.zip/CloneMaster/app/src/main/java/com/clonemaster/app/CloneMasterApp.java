package com.clonemaster.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.io.PrintWriter;
import java.io.StringWriter;

public class CloneMasterApp extends Application {

    private Activity currentActivity = null;

    @Override
    public void onCreate() {
        super.onCreate();

        // Global crash handler — screen pe error dikhao
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            String errorMsg = sw.toString();

            new Handler(Looper.getMainLooper()).post(() -> {
                if (currentActivity != null) {
                    try {
                        new AlertDialog.Builder(currentActivity)
                            .setTitle("❌ Crash Details")
                            .setMessage(errorMsg.length() > 1500
                                ? errorMsg.substring(0, 1500) + "\n..."
                                : errorMsg)
                            .setPositiveButton("Close App", (d, w) -> System.exit(1))
                            .setCancelable(false)
                            .show();
                    } catch (Exception e) {
                        System.exit(1);
                    }
                } else {
                    System.exit(1);
                }
            });
        });

        // Track current activity
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) { currentActivity = a; }
            @Override public void onActivityStarted(Activity a) { currentActivity = a; }
            @Override public void onActivityResumed(Activity a) { currentActivity = a; }
            @Override public void onActivityPaused(Activity a) {}
            @Override public void onActivityStopped(Activity a) {}
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
            @Override public void onActivityDestroyed(Activity a) { if (currentActivity == a) currentActivity = null; }
        });
    }
}
