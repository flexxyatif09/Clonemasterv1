# Add project specific ProGuard rules here.
-keep class com.clonemaster.app.models.** { *; }
-keep class com.clonemaster.app.utils.** { *; }
