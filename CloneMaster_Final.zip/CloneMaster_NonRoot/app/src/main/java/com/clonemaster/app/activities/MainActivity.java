package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.CloneAdapter;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements CloneAdapter.CloneClickListener {

    private CloneAdapter cloneAdapter;
    private CloneManager cloneManager;
    private TextView tvAllocated;
    private TextView tvSecureSpaceLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cloneManager = CloneManager.getInstance(this);
        setupViews();
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshClones();
    }

    private void setupViews() {
        tvAllocated = findViewById(R.id.tv_allocated);
        tvSecureSpaceLabel = findViewById(R.id.tv_secure_space_label);

        if (tvSecureSpaceLabel != null) {
            tvSecureSpaceLabel.setText("SECURE SPACE ACTIVE — VIRTUAL DUAL ACCOUNT");
        }

        MaterialCardView deployCard = findViewById(R.id.card_deploy);
        if (deployCard != null) {
            deployCard.setOnClickListener(v -> startActivity(new Intent(this, AddCloneActivity.class)));
        }

        View ivAvatar = findViewById(R.id.iv_avatar);
        if (ivAvatar != null) {
            ivAvatar.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        }

        RecyclerView recyclerView = findViewById(R.id.rv_clones);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
            cloneAdapter = new CloneAdapter(this, this);
            recyclerView.setAdapter(cloneAdapter);
        }
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) return true;
            else if (id == R.id.nav_add) { startActivity(new Intent(this, AddCloneActivity.class)); return true; }
            else if (id == R.id.nav_locker) { startActivity(new Intent(this, LockerActivity.class)); return true; }
            else if (id == R.id.nav_settings) { startActivity(new Intent(this, SettingsActivity.class)); return true; }
            return false;
        });
    }

    private void refreshClones() {
        if (cloneAdapter == null) return;
        List<CloneInstance> clones = cloneManager.getCloneInstances();
        cloneAdapter.updateClones(clones);
        if (tvAllocated != null) tvAllocated.setText(clones.size() + " Allocated");
    }

    @Override
    public void onCloneClick(CloneInstance clone) {
        boolean launched = cloneManager.launchClone(clone);
        if (!launched) {
            new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("App Not Found")
                .setMessage(clone.getAppName() + " is not installed. Install it from Play Store?")
                .setPositiveButton("Open Play Store", (d, w) -> cloneManager.launchClone(clone))
                .setNegativeButton("Cancel", null)
                .show();
        }
    }

    @Override
    public void onCloneLongClick(CloneInstance clone) {
        String[] options = {"Launch App", clone.isHibernated() ? "Wake Up" : "Hibernate", "Remove Clone"};
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(clone.getAppName())
            .setItems(options, (dialog, which) -> {
                if (which == 0) cloneManager.launchClone(clone);
                else if (which == 1) {
                    if (clone.isHibernated()) cloneManager.wakeClone(clone);
                    else cloneManager.hibernateClone(clone);
                    refreshClones();
                } else {
                    new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Remove Clone")
                        .setMessage("Remove " + clone.getAppName() + " clone?")
                        .setPositiveButton("Remove", (d, w) -> { cloneManager.removeClone(clone.getId()); refreshClones(); })
                        .setNegativeButton("Cancel", null).show();
                }
            }).show();
    }
}
