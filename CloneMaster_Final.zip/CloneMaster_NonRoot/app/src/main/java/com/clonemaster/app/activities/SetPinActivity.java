package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.PrefsManager;

public class SetPinActivity extends AppCompatActivity {

    private final StringBuilder pinBuilder = new StringBuilder();
    private final StringBuilder confirmBuilder = new StringBuilder();
    private boolean confirmMode = false;
    private String firstPin = "";

    private View[] dotViews;
    private TextView tvTitle, tvSubtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        tvTitle = findViewById(R.id.tv_pin_title);
        tvSubtitle = findViewById(R.id.tv_pin_subtitle);

        tvTitle.setText("Set Security PIN");
        tvSubtitle.setText("Create a 4-digit PIN for Clone Master");

        dotViews = new View[]{
            findViewById(R.id.dot1),
            findViewById(R.id.dot2),
            findViewById(R.id.dot3),
            findViewById(R.id.dot4)
        };

        setupNumpad();
    }

    private void setupNumpad() {
        int[] numIds = {
            R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3,
            R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7,
            R.id.btn_8, R.id.btn_9
        };

        for (int i = 0; i < numIds.length; i++) {
            final String num = String.valueOf(i);
            View btn = findViewById(numIds[i]);
            if (btn != null) {
                btn.setOnClickListener(v -> appendDigit(num));
            }
        }

        View btnDelete = findViewById(R.id.btn_delete);
        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> deleteDigit());
        }
    }

    private void appendDigit(String digit) {
        StringBuilder current = confirmMode ? confirmBuilder : pinBuilder;
        if (current.length() < 4) {
            current.append(digit);
            updateDots(current.length());

            if (current.length() == 4) {
                if (!confirmMode) {
                    firstPin = current.toString();
                    confirmMode = true;
                    pinBuilder.setLength(0);
                    updateDots(0);
                    tvTitle.setText("Confirm PIN");
                    tvSubtitle.setText("Re-enter your 4-digit PIN");
                    confirmBuilder.setLength(0);
                } else {
                    verifyPins();
                }
            }
        }
    }

    private void deleteDigit() {
        StringBuilder current = confirmMode ? confirmBuilder : pinBuilder;
        if (current.length() > 0) {
            current.deleteCharAt(current.length() - 1);
            updateDots(current.length());
        }
    }

    private void verifyPins() {
        if (firstPin.equals(confirmBuilder.toString())) {
            PrefsManager.getInstance(this).setPin(firstPin);
            Toast.makeText(this, "PIN set successfully!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            Toast.makeText(this, "PINs do not match. Try again.", Toast.LENGTH_SHORT).show();
            confirmMode = false;
            firstPin = "";
            pinBuilder.setLength(0);
            confirmBuilder.setLength(0);
            updateDots(0);
            tvTitle.setText("Set Security PIN");
            tvSubtitle.setText("Create a 4-digit PIN for Clone Master");
        }
    }

    private void updateDots(int filled) {
        for (int i = 0; i < dotViews.length; i++) {
            if (dotViews[i] != null) {
                dotViews[i].setBackgroundResource(
                    i < filled ? R.drawable.dot_filled : R.drawable.dot_empty
                );
            }
        }
    }
}
