package com.clonemaster.app;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.multidex.MultiDex;

import com.clonemaster.app.workprofile.WorkProfileManager;

public class CloneMasterApp extends Application {
    private static final String TAG = "CloneMasterApp";
    private static CloneMasterApp instance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Work Profile status check
        WorkProfileManager wpm = WorkProfileManager.getInstance(this);
        if (wpm.isWorkProfileCreated()) {
            Log.d(TAG, "Work Profile ACTIVE - True 2nd account ready!");
        } else {
            Log.d(TAG, "Work Profile not yet setup - will prompt user");
        }
    }

    public static CloneMasterApp getInstance() { return instance; }
}
