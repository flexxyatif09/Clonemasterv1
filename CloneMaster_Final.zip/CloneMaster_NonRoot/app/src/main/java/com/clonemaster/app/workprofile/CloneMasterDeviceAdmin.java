package com.clonemaster.app.workprofile;

import android.app.admin.DeviceAdminReceiver;

// Stub - non-root mode mein use nahi hota
public class CloneMasterDeviceAdmin extends DeviceAdminReceiver {}
