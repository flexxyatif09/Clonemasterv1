package com.clonemaster.app.models;

import android.graphics.drawable.Drawable;

public class CloneInstance {
    private String id;
    private String appName;
    private String packageName;
    private Drawable icon;
    private boolean isRunning;
    private int pid;
    private boolean isHibernated;
    private long createdAt;
    private int virtualUserId = 1;
    private boolean isVirtualInstalled = false;

    public CloneInstance(String id, String appName, String packageName, Drawable icon) {
        this.id = id;
        this.appName = appName;
        this.packageName = packageName;
        this.icon = icon;
        this.isRunning = false;
        this.pid = 0;
        this.isHibernated = false;
        this.createdAt = System.currentTimeMillis();
    }

    public CloneInstance(String id, String appName, String packageName,
                         Drawable icon, int virtualUserId) {
        this(id, appName, packageName, icon);
        this.virtualUserId = virtualUserId;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }

    public String getPackageName() { return packageName; }
    public void setPackageName(String packageName) { this.packageName = packageName; }

    public Drawable getIcon() { return icon; }
    public void setIcon(Drawable icon) { this.icon = icon; }

    public boolean isRunning() { return isRunning; }
    public void setRunning(boolean running) {
        isRunning = running;
        if (running) isHibernated = false;
    }

    public int getPid() { return pid; }
    public void setPid(int pid) { this.pid = pid; }

    public boolean isHibernated() { return isHibernated; }
    public void setHibernated(boolean hibernated) {
        isHibernated = hibernated;
        if (hibernated) isRunning = false;
    }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long v) { this.createdAt = v; }

    public int getVirtualUserId() { return virtualUserId; }
    public void setVirtualUserId(int virtualUserId) { this.virtualUserId = virtualUserId; }

    public boolean isVirtualInstalled() { return isVirtualInstalled; }
    public void setVirtualInstalled(boolean v) { this.isVirtualInstalled = v; }

    public String getDisplayPid() {
        return isRunning ? String.valueOf(pid) : "----";
    }

    public String getStatusText() {
        if (isRunning) return "Running";
        if (isHibernated) return "Hibernated";
        return "Stopped";
    }

    public String getCloneLabel() {
        return "Clone " + virtualUserId;
    }
}
