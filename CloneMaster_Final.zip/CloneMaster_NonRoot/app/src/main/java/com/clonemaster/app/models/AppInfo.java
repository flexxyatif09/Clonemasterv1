package com.clonemaster.app.models;

import android.graphics.drawable.Drawable;

public class AppInfo {
    private String appName;
    private String packageName;
    private Drawable icon;
    private long appSize;
    private String category;
    private boolean isRunning;
    private int pid;
    private boolean isHibernated;
    private String cloneId;

    public AppInfo() {}

    public AppInfo(String appName, String packageName, Drawable icon, long appSize, String category) {
        this.appName = appName;
        this.packageName = packageName;
        this.icon = icon;
        this.appSize = appSize;
        this.category = category;
        this.isRunning = false;
        this.pid = 0;
        this.isHibernated = false;
        this.cloneId = "";
    }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }

    public String getPackageName() { return packageName; }
    public void setPackageName(String packageName) { this.packageName = packageName; }

    public Drawable getIcon() { return icon; }
    public void setIcon(Drawable icon) { this.icon = icon; }

    public long getAppSize() { return appSize; }
    public void setAppSize(long appSize) { this.appSize = appSize; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public boolean isRunning() { return isRunning; }
    public void setRunning(boolean running) { isRunning = running; }

    public int getPid() { return pid; }
    public void setPid(int pid) { this.pid = pid; }

    public boolean isHibernated() { return isHibernated; }
    public void setHibernated(boolean hibernated) { isHibernated = hibernated; }

    public String getCloneId() { return cloneId; }
    public void setCloneId(String cloneId) { this.cloneId = cloneId; }

    public String getFormattedSize() {
        if (appSize <= 0) return "Unknown";
        if (appSize < 1024) return appSize + " B";
        else if (appSize < 1024 * 1024) return (appSize / 1024) + " KB";
        else return (appSize / (1024 * 1024)) + " MB";
    }
}
