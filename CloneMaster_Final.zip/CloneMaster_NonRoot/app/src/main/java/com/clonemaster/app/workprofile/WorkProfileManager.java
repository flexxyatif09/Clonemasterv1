package com.clonemaster.app.workprofile;

import android.content.Context;

public class WorkProfileManager {
    private static WorkProfileManager instance;
    private WorkProfileManager(Context context) {}
    public static WorkProfileManager getInstance(Context context) {
        if (instance == null) instance = new WorkProfileManager(context);
        return instance;
    }
    public boolean isWorkProfileCreated() { return false; }
    public boolean isProfileOwner() { return false; }
    public void installAppInWorkProfile(String pkg, AppInstallCallback cb) { if (cb != null) cb.onFailure("Non-root mode"); }
    public boolean launchAppInWorkProfile(String pkg) { return false; }
    public interface AppInstallCallback {
        void onSuccess();
        void onNeedManualInstall(String pkg);
        void onFailure(String error);
    }
}
