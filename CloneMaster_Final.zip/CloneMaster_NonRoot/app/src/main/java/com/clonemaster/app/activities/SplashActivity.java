package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.PrefsManager;
import com.clonemaster.app.workprofile.WorkProfileManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        TextView tvTitle = findViewById(R.id.tv_title);
        TextView tvSubtitle = findViewById(R.id.tv_subtitle);

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(1200); fadeIn.setFillAfter(true);
        tvTitle.startAnimation(fadeIn);

        AlphaAnimation fadeIn2 = new AlphaAnimation(0f, 1f);
        fadeIn2.setDuration(1500); fadeIn2.setStartOffset(400); fadeIn2.setFillAfter(true);
        tvSubtitle.startAnimation(fadeIn2);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            PrefsManager prefs = PrefsManager.getInstance(this);
            WorkProfileManager wpm = WorkProfileManager.getInstance(this);
            Intent intent;

            if (prefs.isFirstLaunch()) {
                // Pehli baar - Work Profile setup screen dikhao
                intent = new Intent(this, WorkProfileSetupActivity.class);
                prefs.setFirstLaunch(false);
            } else if (prefs.hasPin()) {
                intent = new Intent(this, PinActivity.class);
            } else {
                intent = new Intent(this, MainActivity.class);
            }

            startActivity(intent);
            finish();
        }, 2200);
    }
}
