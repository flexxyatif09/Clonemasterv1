package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

public class LockerActivity extends AppCompatActivity {

    private CloneManager cloneManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locker);

        cloneManager = CloneManager.getInstance(this);

        setupBottomNav();
        setupViews();
    }

    private void setupViews() {
        TextView tvTitle = findViewById(R.id.tv_locker_title);
        if (tvTitle != null) {
            tvTitle.setText("Privacy Locker");
        }

        // Load locked apps list
        RecyclerView rv = findViewById(R.id.rv_locked_apps);
        if (rv != null) {
            rv.setLayoutManager(new LinearLayoutManager(this));
            List<AppInfo> installedApps = cloneManager.getInstalledApps();

            AppListAdapter adapter = new AppListAdapter(this, appInfo -> {
                Toast.makeText(this, appInfo.getAppName() + " added to locker", Toast.LENGTH_SHORT).show();
            });

            rv.setAdapter(adapter);
            adapter.updateApps(installedApps, cloneManager);
        }
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        if (bottomNav == null) return;

        bottomNav.setSelectedItemId(R.id.nav_locker);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
                return true;
            } else if (id == R.id.nav_add) {
                startActivity(new Intent(this, AddCloneActivity.class));
                return true;
            } else if (id == R.id.nav_locker) {
                return true;
            } else if (id == R.id.nav_settings) {
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }
}
