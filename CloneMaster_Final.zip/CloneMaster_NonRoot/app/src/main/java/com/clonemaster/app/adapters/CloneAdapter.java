package com.clonemaster.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.models.CloneInstance;

import java.util.ArrayList;
import java.util.List;

public class CloneAdapter extends RecyclerView.Adapter<CloneAdapter.CloneViewHolder> {

    public interface CloneClickListener {
        void onCloneClick(CloneInstance clone);
        void onCloneLongClick(CloneInstance clone);
    }

    private final Context context;
    private final CloneClickListener listener;
    private List<CloneInstance> clones = new ArrayList<>();

    public CloneAdapter(Context context, CloneClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void updateClones(List<CloneInstance> newClones) {
        this.clones = new ArrayList<>(newClones);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CloneViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_clone, parent, false);
        return new CloneViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CloneViewHolder holder, int position) {
        CloneInstance clone = clones.get(position);
        holder.bind(clone);
    }

    @Override
    public int getItemCount() {
        return clones.size();
    }

    class CloneViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivIcon;
        private final TextView tvName, tvPid, tvStatus;
        private final View statusDot;

        CloneViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_app_icon);
            tvName = itemView.findViewById(R.id.tv_app_name);
            tvPid = itemView.findViewById(R.id.tv_pid);
            tvStatus = itemView.findViewById(R.id.tv_status);
            statusDot = itemView.findViewById(R.id.status_dot);
        }

        void bind(CloneInstance clone) {
            if (ivIcon != null) ivIcon.setImageDrawable(clone.getIcon());
            if (tvName != null) tvName.setText(clone.getAppName());
            if (tvPid != null) tvPid.setText("PID: " + clone.getDisplayPid());
            if (tvStatus != null) {
                tvStatus.setText(clone.getStatusText());
                if (clone.isRunning()) {
                    tvStatus.setTextColor(context.getColor(R.color.accent_cyan));
                } else {
                    tvStatus.setTextColor(context.getColor(R.color.text_secondary));
                }
            }
            if (statusDot != null) {
                statusDot.setBackgroundResource(
                    clone.isRunning() ? R.drawable.dot_active : R.drawable.dot_inactive
                );
            }

            itemView.setOnClickListener(v -> listener.onCloneClick(clone));
            itemView.setOnLongClickListener(v -> {
                listener.onCloneLongClick(clone);
                return true;
            });
        }
    }
}
