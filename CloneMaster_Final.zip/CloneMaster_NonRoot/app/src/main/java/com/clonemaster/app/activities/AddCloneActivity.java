package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.adapters.AppListAdapter;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.models.CloneInstance;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class AddCloneActivity extends AppCompatActivity implements AppListAdapter.AppClickListener {

    private AppListAdapter adapter;
    private CloneManager cloneManager;
    private List<AppInfo> allApps = new ArrayList<>();
    private String currentFilter = "All Apps";
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_clone);
        cloneManager = CloneManager.getInstance(this);
        setupViews();
        showWorkProfileBanner();
        loadApps();
    }

    private void setupViews() {
        View btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        etSearch = findViewById(R.id.et_search);
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterApps(s.toString(), currentFilter);
                }
                @Override public void afterTextChanged(Editable s) {}
            });
        }

        ChipGroup chipGroup = findViewById(R.id.chip_group);
        if (chipGroup != null) {
            chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
                if (!checkedIds.isEmpty()) {
                    Chip chip = group.findViewById(checkedIds.get(0));
                    if (chip != null) {
                        currentFilter = chip.getText().toString();
                        filterApps(etSearch != null ? etSearch.getText().toString() : "", currentFilter);
                    }
                }
            });
        }

        RecyclerView recyclerView = findViewById(R.id.rv_apps);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new AppListAdapter(this, this);
            recyclerView.setAdapter(adapter);
        }
    }

    private void showWorkProfileBanner() {
        View banner = findViewById(R.id.banner_work_profile);
        if (banner == null) return;

        if (cloneManager.isWorkProfileActive()) {
            banner.setVisibility(View.GONE); // Already setup - no banner needed
        } else {
            banner.setVisibility(View.VISIBLE);
            banner.setOnClickListener(v ->
                startActivity(new Intent(this, WorkProfileSetupActivity.class)));
        }
    }

    private void loadApps() {
        new Thread(() -> {
            allApps = cloneManager.getInstalledApps();
            runOnUiThread(() -> filterApps("", "All Apps"));
        }).start();
    }

    private void filterApps(String query, String category) {
        List<AppInfo> filtered = new ArrayList<>();
        for (AppInfo app : allApps) {
            boolean matchesQuery = query.isEmpty()
                || app.getAppName().toLowerCase().contains(query.toLowerCase())
                || app.getPackageName().toLowerCase().contains(query.toLowerCase());
            boolean matchesCategory = category.equals("All Apps")
                || app.getCategory().equalsIgnoreCase(category);
            if (matchesQuery && matchesCategory) filtered.add(app);
        }
        if (adapter != null) adapter.updateApps(filtered, cloneManager);
    }

    @Override
    public void onAppAdd(AppInfo appInfo) {
        if (cloneManager.isAlreadyCloned(appInfo.getPackageName())) {
            Toast.makeText(this, appInfo.getAppName() + " is already cloned!", Toast.LENGTH_SHORT).show();
            return;
        }
        CloneInstance clone = cloneManager.addClone(appInfo);
        String msg = cloneManager.isWorkProfileActive()
            ? "✓ " + appInfo.getAppName() + " cloned! 2nd account ready."
            : "✓ " + appInfo.getAppName() + " added. Setup Work Profile for 2nd account.";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if (adapter != null) adapter.notifyDataSetChanged();
        finish();
    }
}
