package com.clonemaster.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.clonemaster.app.R;
import com.clonemaster.app.utils.PrefsManager;

import java.util.concurrent.Executor;

public class PinActivity extends AppCompatActivity {

    private final StringBuilder pinBuilder = new StringBuilder();
    private View[] dotViews;
    private TextView tvForgotPin;
    private int attempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        TextView tvTitle = findViewById(R.id.tv_pin_title);
        TextView tvSubtitle = findViewById(R.id.tv_pin_subtitle);
        tvTitle.setText("Enter Security PIN");
        tvSubtitle.setText("Access your Privacy Locker");

        tvForgotPin = findViewById(R.id.tv_forgot_pin);
        if (tvForgotPin != null) {
            tvForgotPin.setVisibility(View.VISIBLE);
            tvForgotPin.setOnClickListener(v -> showForgotPinDialog());
        }

        dotViews = new View[]{
            findViewById(R.id.dot1),
            findViewById(R.id.dot2),
            findViewById(R.id.dot3),
            findViewById(R.id.dot4)
        };

        setupNumpad();

        // Auto-try biometric if enabled
        if (PrefsManager.getInstance(this).isBiometricEnabled()) {
            showBiometricPrompt();
        }
    }

    private void setupNumpad() {
        int[] numIds = {
            R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3,
            R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7,
            R.id.btn_8, R.id.btn_9
        };

        for (int i = 0; i < numIds.length; i++) {
            final String num = String.valueOf(i);
            View btn = findViewById(numIds[i]);
            if (btn != null) {
                btn.setOnClickListener(v -> appendDigit(num));
            }
        }

        View btnDelete = findViewById(R.id.btn_delete);
        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> deleteDigit());
        }
    }

    private void appendDigit(String digit) {
        if (pinBuilder.length() < 4) {
            pinBuilder.append(digit);
            updateDots(pinBuilder.length());

            if (pinBuilder.length() == 4) {
                checkPin();
            }
        }
    }

    private void deleteDigit() {
        if (pinBuilder.length() > 0) {
            pinBuilder.deleteCharAt(pinBuilder.length() - 1);
            updateDots(pinBuilder.length());
        }
    }

    private void checkPin() {
        String savedPin = PrefsManager.getInstance(this).getPin();
        if (pinBuilder.toString().equals(savedPin)) {
            navigateToMain();
        } else {
            attempts++;
            pinBuilder.setLength(0);
            updateDots(0);
            shakeAnimation();
            vibrate();
        }
    }

    private void navigateToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void shakeAnimation() {
        View dotsContainer = findViewById(R.id.dots_container);
        if (dotsContainer != null) {
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            dotsContainer.startAnimation(shake);
        }
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

    private void showBiometricPrompt() {
        BiometricManager biometricManager = BiometricManager.from(this);
        if (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                == BiometricManager.BIOMETRIC_SUCCESS) {

            Executor executor = ContextCompat.getMainExecutor(this);
            BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        navigateToMain();
                    }
                });

            BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Clone Master")
                .setSubtitle("Biometric Authentication")
                .setNegativeButtonText("Use PIN")
                .build();

            biometricPrompt.authenticate(promptInfo);
        }
    }

    private void showForgotPinDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Reset PIN")
            .setMessage("This will clear all your clone data and settings. Are you sure?")
            .setPositiveButton("Reset", (dialog, which) -> {
                PrefsManager.getInstance(this).clearAll();
                startActivity(new Intent(this, SetPinActivity.class));
                finish();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void updateDots(int filled) {
        for (int i = 0; i < dotViews.length; i++) {
            if (dotViews[i] != null) {
                dotViews[i].setBackgroundResource(
                    i < filled ? R.drawable.dot_filled : R.drawable.dot_empty
                );
            }
        }
    }
}
