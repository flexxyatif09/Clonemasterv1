package com.clonemaster.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.clonemaster.app.R;
import com.clonemaster.app.models.AppInfo;
import com.clonemaster.app.utils.CloneManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppViewHolder> {

    public interface AppClickListener {
        void onAppAdd(AppInfo appInfo);
    }

    private final Context context;
    private final AppClickListener listener;
    private List<AppInfo> apps = new ArrayList<>();
    private CloneManager cloneManager;

    public AppListAdapter(Context context, AppClickListener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void updateApps(List<AppInfo> newApps, CloneManager manager) {
        this.apps = new ArrayList<>(newApps);
        this.cloneManager = manager;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        AppInfo app = apps.get(position);
        holder.bind(app);
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    class AppViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivIcon;
        private final TextView tvName, tvCategory;
        private final MaterialButton btnAdd;

        AppViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_app_icon);
            tvName = itemView.findViewById(R.id.tv_app_name);
            tvCategory = itemView.findViewById(R.id.tv_category);
            btnAdd = itemView.findViewById(R.id.btn_add);
        }

        void bind(AppInfo app) {
            if (ivIcon != null) ivIcon.setImageDrawable(app.getIcon());
            if (tvName != null) tvName.setText(app.getAppName());
            if (tvCategory != null) {
                String catSize = app.getCategory() + " • " + app.getFormattedSize();
                tvCategory.setText(catSize);
            }

            if (btnAdd != null) {
                boolean isCloned = cloneManager != null && cloneManager.isAlreadyCloned(app.getPackageName());
                if (isCloned) {
                    btnAdd.setText("Cloned ✓");
                    btnAdd.setEnabled(false);
                    btnAdd.setAlpha(0.5f);
                } else {
                    btnAdd.setText("+ Add");
                    btnAdd.setEnabled(true);
                    btnAdd.setAlpha(1f);
                    btnAdd.setOnClickListener(v -> listener.onAppAdd(app));
                }
            }

            itemView.setOnClickListener(v -> {
                if (cloneManager == null || !cloneManager.isAlreadyCloned(app.getPackageName())) {
                    listener.onAppAdd(app);
                }
            });
        }
    }
}
