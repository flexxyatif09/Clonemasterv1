package com.clonemaster.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {
    private static final String PREF_NAME = "CloneMasterPrefs";
    private static final String KEY_PIN = "security_pin";
    private static final String KEY_BIOMETRIC = "biometric_enabled";
    private static final String KEY_INVISIBLE_INSTALL = "invisible_install";
    private static final String KEY_NOTIFICATION_SEG = "notification_segregation";
    private static final String KEY_FIRST_LAUNCH = "first_launch";
    private static final String KEY_CLONES_JSON = "clones_json";
    private static final String KEY_LOCKED_APPS = "locked_apps";

    private static PrefsManager instance;
    private final SharedPreferences prefs;

    private PrefsManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static PrefsManager getInstance(Context context) {
        if (instance == null) {
            instance = new PrefsManager(context);
        }
        return instance;
    }

    public void setPin(String pin) {
        prefs.edit().putString(KEY_PIN, pin).apply();
    }

    public String getPin() {
        return prefs.getString(KEY_PIN, "");
    }

    public boolean hasPin() {
        return !getPin().isEmpty();
    }

    public void setBiometricEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_BIOMETRIC, enabled).apply();
    }

    public boolean isBiometricEnabled() {
        return prefs.getBoolean(KEY_BIOMETRIC, false);
    }

    public void setInvisibleInstall(boolean enabled) {
        prefs.edit().putBoolean(KEY_INVISIBLE_INSTALL, enabled).apply();
    }

    public boolean isInvisibleInstall() {
        return prefs.getBoolean(KEY_INVISIBLE_INSTALL, true);
    }

    public void setNotificationSegregation(boolean enabled) {
        prefs.edit().putBoolean(KEY_NOTIFICATION_SEG, enabled).apply();
    }

    public boolean isNotificationSegregation() {
        return prefs.getBoolean(KEY_NOTIFICATION_SEG, true);
    }

    public boolean isFirstLaunch() {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true);
    }

    public void setFirstLaunch(boolean first) {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, first).apply();
    }

    public void saveClonesJson(String json) {
        prefs.edit().putString(KEY_CLONES_JSON, json).apply();
    }

    public String getClonesJson() {
        return prefs.getString(KEY_CLONES_JSON, "[]");
    }

    public void saveLockedApps(String json) {
        prefs.edit().putString(KEY_LOCKED_APPS, json).apply();
    }

    public String getLockedApps() {
        return prefs.getString(KEY_LOCKED_APPS, "[]");
    }

    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
