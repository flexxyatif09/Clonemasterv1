package com.clonemaster.app.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.clonemaster.app.R;

public class WorkProfileSetupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Simple finish - directly back to main
        Toast.makeText(this, "Virtual Space is ready! No setup needed.", Toast.LENGTH_SHORT).show();
        finish();
    }
}
