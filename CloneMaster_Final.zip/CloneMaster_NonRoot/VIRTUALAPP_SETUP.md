# VirtualApp Integration Guide

## Virtual App Library Setup

Clone Master ka true dual space feature **VirtualApp** library use karta hai.

### Option A: VirtualApp JAR (Recommended)

VirtualApp open source hai: https://github.com/asLody/VirtualApp

**Steps:**
1. VirtualApp ko clone karo:
   ```bash
   git clone https://github.com/asLody/VirtualApp.git
   cd VirtualApp
   ./gradlew assembleRelease
   ```

2. Generate hua AAR/JAR copy karo:
   ```
   VirtualApp/lib/build/outputs/aar/lib-release.aar
   ```
   → `CloneMaster/app/libs/virtualapp.aar` me paste karo

3. `app/build.gradle` me add karo:
   ```gradle
   implementation files('libs/virtualapp.aar')
   ```

### Option B: Alternative - Shadow (Modern replacement)

Shadow aur DroidPlugin bhi available hain:
- https://github.com/Tencent/Shadow
- https://github.com/DroidPluginTeam/DroidPlugin

### Option C: Without VirtualApp (Current mode)

Agar VirtualApp nahi mila toh app **fallback mode** me kaam karta hai:
- UI puri tarah kaam karti hai ✅
- Clone management kaam karta hai ✅
- **Alag account nahi chalega** ❌ (original app hi open hoga)

---

## True Dual Space kaise kaam karta hai?

```
Device pe WhatsApp (Account 1: +91 9876543210)
        ↓
Clone Master → Virtual Space (userId=1)
        ↓
WhatsApp Clone (Account 2: +91 9123456789)
```

Dono accounts simultaneously chal sakte hain, alag data ke saath!

---

## Technical Details

- `VirtualCore.java` - VirtualApp ke saath communicate karta hai
- `VirtualAppEngine.java` - High-level clone operations
- `CloneManager.java` - UI aur business logic
- `CloneMasterApp.java` - App startup pe engine init

Virtual userId system:
- `userId=0` → Original app (device ka)
- `userId=1` → 1st clone (2nd account)  
- `userId=2` → 2nd clone (3rd account)
