# 🛡️ Clone Master — True Dual Space App

Run **2 accounts of any app** on 1 phone — WhatsApp, Instagram, Facebook, and more.
Uses Android's official **Work Profile API** — no root required.

## ✨ How It Works

```
Your Phone
├── Personal Profile  →  WhatsApp Account 1 (+91 9876543210)
└── Work Profile      →  WhatsApp Clone   (+91 9123456789)  ← Clone Master
```

Both run simultaneously with **completely separate data, notifications, and storage**.

## 📱 Features

| Feature | Status |
|---------|--------|
| True 2nd account (Work Profile) | ✅ |
| WhatsApp 2 numbers | ✅ |
| Instagram / Facebook 2 accounts | ✅ |
| PIN + Biometric lock | ✅ |
| No root required | ✅ |
| Privacy Locker | ✅ |
| Storage Optimizer | ✅ |

## 🚀 Build APK — GitHub Actions

### Step 1 — Upload to GitHub
```bash
git init
git add .
git commit -m "Clone Master — True Dual Space"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/clone-master.git
git push -u origin main
```

### Step 2 — APK auto-builds
- Go to repo → **Actions** tab
- Watch **"Build Clone Master APK"** workflow
- Download from **Artifacts** when complete

### Step 3 — Install & Use
1. Install APK (enable Unknown Sources)
2. Open Clone Master
3. Tap **"Create Work Profile"** → Follow Android setup
4. Go to **Add** → Select WhatsApp
5. Tap **Clone** on home screen → **WhatsApp opens with fresh install**
6. Login with your 2nd number 🎉

## 📁 Project Structure

```
CloneMaster/
├── activities/
│   ├── WorkProfileSetupActivity.java   ← Work Profile setup screen
│   ├── MainActivity.java               ← Home (clone grid)
│   ├── AddCloneActivity.java           ← Select app to clone
│   ├── PinActivity.java                ← PIN security
│   └── SettingsActivity.java           ← Settings + optimization
├── workprofile/
│   ├── WorkProfileManager.java         ← Core Work Profile logic
│   └── CloneMasterDeviceAdmin.java     ← Device Admin receiver
├── utils/
│   └── CloneManager.java               ← Clone management
└── .github/workflows/
    └── build-apk.yml                   ← Auto APK build
```

## ⚙️ Requirements
- Android 5.0+ (API 21+)
- JDK 17 for building
